(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Acting _ the income_atlas_1", frames: [[1202,496,124,76],[1202,574,124,76],[1202,340,150,76],[1202,418,150,76],[0,1300,1532,381],[1202,0,208,66],[1202,68,208,66],[1202,136,208,66],[1202,204,208,66],[1202,272,208,66],[0,0,1200,1298]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_12 = function() {
	this.initialize(ss["Acting _ the income_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_11 = function() {
	this.initialize(ss["Acting _ the income_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_10 = function() {
	this.initialize(ss["Acting _ the income_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(ss["Acting _ the income_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_8 = function() {
	this.initialize(ss["Acting _ the income_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_7 = function() {
	this.initialize(ss["Acting _ the income_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_6 = function() {
	this.initialize(ss["Acting _ the income_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_5 = function() {
	this.initialize(ss["Acting _ the income_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4 = function() {
	this.initialize(ss["Acting _ the income_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_3 = function() {
	this.initialize(ss["Acting _ the income_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_2 = function() {
	this.initialize(ss["Acting _ the income_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_1 = function() {
	this.initialize(img.CachedBmp_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2480,374);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.uptwo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AtRDIIAAmPIajAAIAAGPgAo+AxISvAAIpGiUg");
	this.shape.setTransform(85,20);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170,40);


(lib.upthree = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AtRDIIAAmPIajAAIAAGPgAo+AxISvAAIpGiUg");
	this.shape.setTransform(85,20);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170,40);


(lib.upone = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AtRDIIAAmPIajAAIAAGPgAo+AxISvAAIpGiUg");
	this.shape.setTransform(85,20);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170,40);


(lib.upfour = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AtRDIIAAmPIajAAIAAGPgAo+AxISvAAIpGiUg");
	this.shape.setTransform(85,20);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170,40);


(lib.upfive = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AtRDIIAAmPIajAAIAAGPgAo+AxISvAAIpGiUg");
	this.shape.setTransform(85,20);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170,40);


(lib.startbutton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {up:0,over:1,down:2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.CachedBmp_11();
	this.instance.setTransform(-15.2,-13.8,0.3362,0.3362);

	this.instance_1 = new lib.CachedBmp_12();
	this.instance_1.setTransform(-18.9,-14.3,0.3362,0.3362);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(2));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAwDDIljAAQgtAAAAgtIAAkrQAAgtAtAAIFjAAIEEAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape.setTransform(2.775,-1.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF6600").s().p("AkpDDQgtAAAAgtIAAkrQAAgtAtAAIJTAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_1.setTransform(3.125,-1.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF6600").s().p("AkfDDQgtAAAAgtIAAkrQAAgtAtAAII/AAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_2.setTransform(0.775,-1.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.5,-21,70.6,39);


(lib.resetbutton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"up":0,"over":1,"down":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.CachedBmp_9();
	this.instance.setTransform(-22.45,-13.8,0.3362,0.3362);

	this.instance_1 = new lib.CachedBmp_10();
	this.instance_1.setTransform(-23.45,-13.8,0.3362,0.3362);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(2));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAwDDIljAAQgtAAAAgtIAAkrQAAgtAtAAIFjAAIEEAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape.setTransform(2.775,-1.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF6600").s().p("AkpDDQgtAAAAgtIAAkrQAAgtAtAAIJTAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_1.setTransform(1.775,-1.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF6600").s().p("AkfDDQgtAAAAgtIAAkrQAAgtAtAAII/AAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_2.setTransform(0.775,-1.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.5,-21,70.6,39);


(lib.helptext = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.instance = new lib.CachedBmp_8();
	this.instance.setTransform(-276.85,-105.3,0.3362,0.3362);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#393939").ss(2,1,1).p("EAoPAKKMhQdAAAIAA0TMBQdAAAg");
	this.shape.setTransform(-19.425,-40.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EgoOAKKIAA0TMBQdAAAIAAUTg");
	this.shape_1.setTransform(-19.425,-40.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.helptext, new cjs.Rectangle(-277.9,-106.3,517,132), null);


(lib.border = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("Eg39AjNQhjAAAAhjMAAAhDTQAAhjBjAAMBv7AAAQBjAAAABjMAAABDTQAABjhjAAgEg39AbUMBotAAAIHOAAMAAAg7QInOAAMhotAAAg");
	this.shape.setTransform(4.05,2.575);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-364,-222.7,736.2,450.6);


(lib.downtwo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AtTjAIakgOIACGPI6jAOgApxgsIJICRIJniag");
	this.shape.setTransform(85.15,20.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170.3,41.4);


(lib.downthree = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AtTjAIakgOIACGPI6jAOgApxgsIJICRIJniag");
	this.shape.setTransform(85.15,20.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170.3,41.4);


(lib.downone = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AtTjAIakgOIACGPI6jAOgApxgsIJICRIJniag");
	this.shape.setTransform(85.15,20.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170.3,41.4);


(lib.downfour = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AtTjAIakgOIACGPI6jAOgApxgsIJICRIJniag");
	this.shape.setTransform(85.15,20.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170.3,41.4);


(lib.downfive = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AtTjAIakgOIACGPI6jAOgApxgsIJICRIJniag");
	this.shape.setTransform(85.15,20.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170.3,41.4);


(lib.helpbutton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"up":0,"over":1,"down":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.helptext();
	this.instance.setTransform(-69.3,-61.75,1,1,0,0,0,66.2,-6.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(2));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AgPBYQgEgFAAgGQAAgIAFgEQAEgEAIgBQAHABAFAEQAEAEAAAIQAAAGgEAFQgEAFgIAAQgIAAgFgFgAgRAmQAAgRAEgJQAEgLAMgLQAMgLADgFQAFgIAAgIQAAgMgGgGQgFgHgMABQgJgBgHAHQgHAGAAAJIgeAAQAAgVAPgOQAPgMAXAAQAZAAAPAMQAOAOAAAWQAAAUgUAVIgPAOQgIAJgBASg");
	this.shape.setTransform(0.625,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgPBYQgEgFAAgGQAAgIAFgEQAEgEAIgBQAHABAFAEQAEAEAAAIQAAAGgEAFQgEAFgIAAQgIAAgFgFgAgRAmQAAgRAEgJQAEgLAMgLQAMgLADgFQAFgIAAgIQAAgMgGgGQgFgHgMABQgJgBgHAHQgHAGAAAJIgeAAQAAgVAPgOQAPgMAXAAQAZAAAPAMQAOAOAAAWQAAAUgUAVIgPAOQgIAJgBASg");
	this.shape_1.setTransform(0.625,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(2));

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ai2DDQgsAAAAguIAAkqQAAgtAsAAIFtAAQAsAAAAAtIAAEqQAAAugsAAg");
	this.shape_2.setTransform(0,-0.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF6600").s().p("Ai2DDQgsAAAAguIAAkqQAAgtAsAAIFtAAQAsAAAAAtIAAEqQAAAugsAAg");
	this.shape_3.setTransform(0,-0.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2}]}).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-413.4,-161.9,517,180.6);


// stage content:
(lib.Actingtheincome = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		
		
		this.start_mc.addEventListener("click", fl_ClickToGoToAndStopAtFrame_10.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_10()
		{
			this.gotoAndStop(1);
		
		}
		
		
		this.reset_mc.addEventListener("click", fl_ClickToGoToAndStopAtFrame_11.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_11()
		{
			this.gotoAndStop(0);
		}
		
		
		var y = 0;
		function fl_MouseClickHandler_2()
		{if (y < 100){
			this.NumCounter.text = ++y;
		}
		}
		function fl_MouseClickHandler_3()
		{if (y > 0){
			this.NumCounter.text = --y;
		}
		}
		this.NumCounter.text = y;
		this.Btn1.addEventListener("click", fl_MouseClickHandler_2.bind(this));
		this.Btn2.addEventListener("click", fl_MouseClickHandler_3.bind(this));
		
		
		var y = 0;
		function fl_MouseClickHandler_4()
		{if (y < 100){
			this.NumCounter1.text = ++y;
		}
		}
		function fl_MouseClickHandler_5()
		{if (y > 0){
			this.NumCounter1.text = --y;
		}
		}
		this.NumCounter1.text = y;
		this.Btn3.addEventListener("click", fl_MouseClickHandler_4.bind(this));
		this.Btn4.addEventListener("click", fl_MouseClickHandler_5.bind(this));
		
		
		var y = 0;
		function fl_MouseClickHandler_6()
		{if (y < 100000){
			this.NumCounter2.text = ++y*1000;
		}
		}
		function fl_MouseClickHandler_7()
		{if (y > 0){
			this.NumCounter2.text = --y*1000;
		}
		}
		this.NumCounter2.text = y;
		this.Btn5.addEventListener("click", fl_MouseClickHandler_6.bind(this));
		this.Btn6.addEventListener("click", fl_MouseClickHandler_7.bind(this));
		
		
		
		var y = 0;
		function fl_MouseClickHandler_8()
		{if (y < 1000){
			this.NumCounter3.text = ++y*100;
		}
		}
		function fl_MouseClickHandler_9()
		{if (y > 0){
			this.NumCounter3.text = --y*100;
		}
		}
		this.NumCounter3.text = y;
		this.Btn7.addEventListener("click", fl_MouseClickHandler_8.bind(this));
		this.Btn8.addEventListener("click", fl_MouseClickHandler_9.bind(this));
		
		
		var y = 0;
		function fl_MouseClickHandler_10()
		{if (y < 100){
			this.NumCounter4.text = ++y;
		}
		}
		function fl_MouseClickHandler_11()
		{if (y > 0){
			this.NumCounter4.text = --y;
		}
		}
		this.NumCounter4.text = y;
		this.Btn9.addEventListener("click", fl_MouseClickHandler_10.bind(this));
		this.Btn10.addEventListener("click", fl_MouseClickHandler_11.bind(this));
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// interface_buttons
	this.help_mc = new lib.helpbutton();
	this.help_mc.name = "help_mc";
	this.help_mc.setTransform(1107.15,737.3,1.487,1.487,0,0,0,0,0.1);
	new cjs.ButtonHelper(this.help_mc, 0, 1, 2);

	this.reset_mc = new lib.resetbutton();
	this.reset_mc.name = "reset_mc";
	this.reset_mc.setTransform(1201.35,738.3,1.487,1.487);
	new cjs.ButtonHelper(this.reset_mc, 0, 1, 2);

	this.Btn4 = new lib.downtwo();
	this.Btn4.name = "Btn4";
	this.Btn4.setTransform(1010.55,254,0.8808,0.7255,0,0,0,96.8,20.7);
	new cjs.ButtonHelper(this.Btn4, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.reset_mc},{t:this.help_mc}]}).to({state:[{t:this.reset_mc},{t:this.help_mc},{t:this.Btn4}]},1).wait(1));

	// border
	this.instance = new lib.border("synched",0);
	this.instance.setTransform(632.7,386.65,1.7386,1.7386);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({startPosition:0},0).wait(1));

	// Text
	this.instance_1 = new lib.CachedBmp_1();
	this.instance_1.setTransform(17.95,238.3,0.5,0.5);

	this.NumCounter2 = new cjs.Text("", "24px 'Roboto'", "#999999");
	this.NumCounter2.name = "NumCounter2";
	this.NumCounter2.textAlign = "center";
	this.NumCounter2.lineHeight = 31;
	this.NumCounter2.lineWidth = 127;
	this.NumCounter2.parent = this;
	this.NumCounter2.setTransform(999.5,355.5);

	this.NumCounter1 = new cjs.Text("", "24px 'Roboto'", "#999999");
	this.NumCounter1.name = "NumCounter1";
	this.NumCounter1.textAlign = "center";
	this.NumCounter1.lineHeight = 31;
	this.NumCounter1.lineWidth = 127;
	this.NumCounter1.parent = this;
	this.NumCounter1.setTransform(999.5,212.6);

	this.NumCounter = new cjs.Text("", "24px 'Roboto'", "#999999");
	this.NumCounter.name = "NumCounter";
	this.NumCounter.textAlign = "center";
	this.NumCounter.lineHeight = 29;
	this.NumCounter.lineWidth = 127;
	this.NumCounter.parent = this;
	this.NumCounter.setTransform(999.5,74.6);

	this.instance_2 = new lib.CachedBmp_2();
	this.instance_2.setTransform(25.35,42.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2},{t:this.NumCounter},{t:this.NumCounter1},{t:this.NumCounter2}]},1).wait(1));

	// buttons
	this.start_mc = new lib.startbutton();
	this.start_mc.name = "start_mc";
	this.start_mc.setTransform(635.8,513.8,1.487,1.487);
	new cjs.ButtonHelper(this.start_mc, 0, 1, 2);

	this.instance_3 = new lib.CachedBmp_7();
	this.instance_3.setTransform(819.4,492.7,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_6();
	this.instance_4.setTransform(821.3,353.5,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_5();
	this.instance_5.setTransform(1075.3,206.2,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_4();
	this.instance_6.setTransform(1073.4,72.6,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_3();
	this.instance_7.setTransform(1073.4,634.5,0.5,0.5);

	this.NumCounter4 = new cjs.Text("", "24px 'Roboto'", "#999999");
	this.NumCounter4.name = "NumCounter4";
	this.NumCounter4.textAlign = "center";
	this.NumCounter4.lineHeight = 31;
	this.NumCounter4.lineWidth = 121;
	this.NumCounter4.parent = this;
	this.NumCounter4.setTransform(996.55,636.5);

	this.NumCounter3 = new cjs.Text("", "24px 'Roboto'", "#999999");
	this.NumCounter3.name = "NumCounter3";
	this.NumCounter3.textAlign = "center";
	this.NumCounter3.lineHeight = 31;
	this.NumCounter3.lineWidth = 127;
	this.NumCounter3.parent = this;
	this.NumCounter3.setTransform(999.5,494.7);

	this.Btn10 = new lib.downfive();
	this.Btn10.name = "Btn10";
	this.Btn10.setTransform(1010.45,676,0.8808,0.7255,0,0,0,96.7,20.8);
	new cjs.ButtonHelper(this.Btn10, 0, 1, 1);

	this.Btn8 = new lib.downfour();
	this.Btn8.name = "Btn8";
	this.Btn8.setTransform(1010.45,550.45,0.8808,0.7255,0,0,0,96.7,42.8);
	new cjs.ButtonHelper(this.Btn8, 0, 1, 1);

	this.Btn6 = new lib.downthree();
	this.Btn6.name = "Btn6";
	this.Btn6.setTransform(1010.45,411.35,0.8808,0.7255,0,0,0,96.7,42.8);
	new cjs.ButtonHelper(this.Btn6, 0, 1, 1);

	this.Btn2 = new lib.downone();
	this.Btn2.name = "Btn2";
	this.Btn2.setTransform(1010.65,130.65,0.8808,0.7255,0,0,0,96.9,42.8);
	new cjs.ButtonHelper(this.Btn2, 0, 1, 1);

	this.Btn9 = new lib.upfive();
	this.Btn9.name = "Btn9";
	this.Btn9.setTransform(1008.45,619.5,0.8824,0.75,0,0,0,96.4,20);
	new cjs.ButtonHelper(this.Btn9, 0, 1, 1);

	this.Btn7 = new lib.upfour();
	this.Btn7.name = "Btn7";
	this.Btn7.setTransform(998.4,477.7,0.8824,0.75,0,0,0,85,20);
	new cjs.ButtonHelper(this.Btn7, 0, 1, 1);

	this.Btn5 = new lib.upthree();
	this.Btn5.name = "Btn5";
	this.Btn5.setTransform(998.4,353.6,0.8824,0.75,0,0,0,85,40.1);
	new cjs.ButtonHelper(this.Btn5, 0, 1, 1);

	this.Btn3 = new lib.uptwo();
	this.Btn3.name = "Btn3";
	this.Btn3.setTransform(1021.65,195.75,0.8824,0.75,0,0,0,109.2,20.2);
	new cjs.ButtonHelper(this.Btn3, 0, 1, 1);

	this.Btn1 = new lib.upone();
	this.Btn1.name = "Btn1";
	this.Btn1.setTransform(989.2,55.5,0.8823,0.75,0,0,0,72.4,17.2);
	new cjs.ButtonHelper(this.Btn1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.start_mc}]}).to({state:[{t:this.Btn1},{t:this.Btn3},{t:this.Btn5},{t:this.Btn7},{t:this.Btn9},{t:this.Btn2},{t:this.Btn6},{t:this.Btn8},{t:this.Btn10},{t:this.NumCounter3},{t:this.NumCounter4},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(639.8,391,640,391.79999999999995);
// library properties:
lib.properties = {
	id: '0B2B3EBA4B645D45A7E84D318570440E',
	width: 1280,
	height: 783,
	fps: 60,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/CachedBmp_1.png?1657640804073", id:"CachedBmp_1"},
		{src:"images/Acting _ the income_atlas_1.png?1657640804032", id:"Acting _ the income_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['0B2B3EBA4B645D45A7E84D318570440E'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;