(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"The eatwell plate_atlas_1", frames: [[512,1888,1532,158],[0,1114,848,312],[0,847,1113,265],[0,0,1567,845],[1059,1297,502,497],[0,1428,510,490],[512,1428,545,458],[1115,847,557,448]]},
		{name:"The eatwell plate_atlas_2", frames: [[0,376,39,80],[1159,0,584,326],[41,376,39,80],[639,0,518,374],[1463,328,124,76],[1589,328,124,76],[1159,328,150,76],[1311,328,150,76],[82,376,39,80],[123,376,39,80],[164,376,39,80],[0,0,637,374],[1745,0,298,442]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_44 = function() {
	this.initialize(ss["The eatwell plate_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_43 = function() {
	this.initialize(ss["The eatwell plate_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_41 = function() {
	this.initialize(ss["The eatwell plate_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_40 = function() {
	this.initialize(ss["The eatwell plate_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_38 = function() {
	this.initialize(ss["The eatwell plate_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_37 = function() {
	this.initialize(ss["The eatwell plate_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_36 = function() {
	this.initialize(ss["The eatwell plate_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_35 = function() {
	this.initialize(ss["The eatwell plate_atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_34 = function() {
	this.initialize(ss["The eatwell plate_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_33 = function() {
	this.initialize(ss["The eatwell plate_atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_32 = function() {
	this.initialize(ss["The eatwell plate_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_30 = function() {
	this.initialize(ss["The eatwell plate_atlas_2"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_29 = function() {
	this.initialize(ss["The eatwell plate_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_27 = function() {
	this.initialize(ss["The eatwell plate_atlas_2"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_26 = function() {
	this.initialize(ss["The eatwell plate_atlas_2"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_42 = function() {
	this.initialize(img.CachedBmp_42);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2474,1310);


(lib.CachedBmp_24 = function() {
	this.initialize(img.CachedBmp_24);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2480,374);


(lib.Screenshot20220524180343 = function() {
	this.initialize(ss["The eatwell plate_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Screenshot_20220524_180423removebgpreview = function() {
	this.initialize(ss["The eatwell plate_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Screenshot_20220524_181628removebgpreview = function() {
	this.initialize(ss["The eatwell plate_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Screenshot_20220524_181643removebgpreview = function() {
	this.initialize(ss["The eatwell plate_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Screenshot_20220524_181715removebgpreview = function() {
	this.initialize(ss["The eatwell plate_atlas_2"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Screenshot_20220524_181809removebgpreview = function() {
	this.initialize(ss["The eatwell plate_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.milkanddairyx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_44();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,19.5,40);


(lib.milkanddairybtn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#444444").s().p("A4fzoMAw+AS3IgIBNQgSDTmjDtQmkDtg4AiIgBABQgBANg2AdQj/CIkOBfQm7CcnPBQg");
	this.shape.setTransform(156.75,125.725);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,313.5,251.5);


(lib.milkanddairy_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_43();
	this.instance.setTransform(208.7,41,0.5,0.5);

	this.instance_1 = new lib.Screenshot_20220524_181809removebgpreview();
	this.instance_1.setTransform(653.2,171.95);

	this.instance_2 = new lib.CachedBmp_42();
	this.instance_2.setTransform(-1.5,-1.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.milkanddairy_mc, new cjs.Rectangle(-1.5,-1.5,1237,655), null);


(lib.meatfishx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_41();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,19.5,40);


(lib.meatfishbtn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#444444").s().p("AtrKpQq3m2B3iaMAtogUeMgNWAmLQsbhoq3m1g");
	this.shape.setTransform(146.9619,122.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,293.9,244.5);


(lib.meatfish_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_40();
	this.instance.setTransform(765.8,128.5,0.5,0.5);

	this.instance_1 = new lib.Screenshot_20220524_181643removebgpreview();
	this.instance_1.setTransform(21.65,180.3);

	this.instance_2 = new lib.CachedBmp_42();
	this.instance_2.setTransform(-1.5,-1.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.meatfish_mc, new cjs.Rectangle(-1.5,-1.5,1237,655), null);


(lib.startbutton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {up:0,over:1,down:2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.CachedBmp_37();
	this.instance.setTransform(-15.2,-13.8,0.3362,0.3362);

	this.instance_1 = new lib.CachedBmp_38();
	this.instance_1.setTransform(-18.9,-14.3,0.3362,0.3362);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(2));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAwDDIljAAQgtAAAAgtIAAkrQAAgtAtAAIFjAAIEEAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape.setTransform(2.775,-1.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF6600").s().p("AkpDDQgtAAAAgtIAAkrQAAgtAtAAIJTAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_1.setTransform(3.125,-1.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF6600").s().p("AkfDDQgtAAAAgtIAAkrQAAgtAtAAII/AAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_2.setTransform(0.775,-1.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.5,-21,70.6,39);


(lib.resetbutton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"up":0,"over":1,"down":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.CachedBmp_35();
	this.instance.setTransform(-22.45,-13.8,0.3362,0.3362);

	this.instance_1 = new lib.CachedBmp_36();
	this.instance_1.setTransform(-23.45,-13.8,0.3362,0.3362);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(2));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAwDDIljAAQgtAAAAgtIAAkrQAAgtAtAAIFjAAIEEAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape.setTransform(2.775,-1.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF6600").s().p("AkpDDQgtAAAAgtIAAkrQAAgtAtAAIJTAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_1.setTransform(1.775,-1.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF6600").s().p("AkfDDQgtAAAAgtIAAkrQAAgtAtAAII/AAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_2.setTransform(0.775,-1.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.5,-21,70.6,39);


(lib.helptext = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.instance = new lib.CachedBmp_34();
	this.instance.setTransform(-276.9,-30.5,0.3362,0.3362);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#393939").ss(2,1,1).p("EAoPAETMhQdAAAIAAolMBQdAAAg");
	this.shape.setTransform(-19.425,-3.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EgoOAETIAAolMBQdAAAIAAIlg");
	this.shape_1.setTransform(-19.425,-3.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.helptext, new cjs.Rectangle(-277.9,-31.5,517,57), null);


(lib.border = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("Eg39AjNQhjAAAAhjMAAAhDTQAAhjBjAAMBv7AAAQBjAAAABjMAAABDTQAABjhjAAgEg39AbUMBotAAAIHOAAMAAAg7QInOAAMhotAAAg");
	this.shape.setTransform(4.05,2.575);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-364,-222.7,736.2,450.6);


(lib.fruitvegbtn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#444444").s().p("A43T/Qh5kogKh1QgKh1gKhJQgGgyAEg6QAFg5BDmHIAyh2IgBAFQASgzAZgzQBXizB5ifQBwiTCAiFQCEiKCWh1QCZh4CnhiQCqhiC2hMQC1hOC/g7QC4g7C7grQC1gpC3geQCqgcCrgRIE+gcICfgKMgAUAiJMgvVAUqQioizh5kog");
	this.shape.setTransform(175.2331,175.35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.6,0,349.29999999999995,350.7);


(lib.fruitsandvegx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_33();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,19.5,40);


(lib.fruitsandveg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_32();
	this.instance.setTransform(520.3,235.75,0.5,0.5);

	this.instance_1 = new lib.Screenshot_20220524_180423removebgpreview();
	this.instance_1.setTransform(13.3,17.75);

	this.instance_2 = new lib.CachedBmp_42();
	this.instance_2.setTransform(-1.5,-1.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fruitsandveg, new cjs.Rectangle(-1.5,-1.5,1237,655), null);


(lib.foodsanddrinkx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_30();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,19.5,40);


(lib.foodsanddrinkbtn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#444444").s().p("AreSaMAMtgl4MAKQAk8QgaCBnlAAQljAApbhFg");
	this.shape.setTransform(73.5,124.6955);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,147,249.4);


(lib.foodsanddrink_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_29();
	this.instance.setTransform(337.9,39.85,0.5,0.5);

	this.instance_1 = new lib.Screenshot_20220524_181715removebgpreview();
	this.instance_1.setTransform(463.1,193.85);

	this.instance_2 = new lib.CachedBmp_42();
	this.instance_2.setTransform(-1.5,-1.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.foodsanddrink_mc, new cjs.Rectangle(-1.5,-1.5,1237,655), null);


(lib.breadricex = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_27();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,19.5,40);


(lib.breadricebtn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#444444").s().p("A7HIsMAAAgiwQGKAdGHBBQGEBAF6BxQFsBuFTCwQFkC5EbEaQEeEcCdFyQCXFlgSGLQgTGLhwDqQhwDphXAtg");
	this.shape.setTransform(173.5751,166.925);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,347.2,333.9);


(lib.breadrice = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_26();
	this.instance.setTransform(233.25,190.05,0.5,0.5);

	this.instance_1 = new lib.Screenshot_20220524_181628removebgpreview();
	this.instance_1.setTransform(712.8,11.3);

	this.instance_2 = new lib.CachedBmp_42();
	this.instance_2.setTransform(-1.5,-1.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.breadrice, new cjs.Rectangle(-1.5,-1.5,1237,655), null);


(lib.helpbutton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"up":0,"over":1,"down":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.helptext();
	this.instance.setTransform(-69.3,-61.75,1,1,0,0,0,66.2,-6.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(2));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AgPBYQgEgFAAgGQAAgIAFgEQAEgEAIgBQAHABAFAEQAEAEAAAIQAAAGgEAFQgEAFgIAAQgIAAgFgFgAgRAmQAAgRAEgJQAEgLAMgLQAMgLADgFQAFgIAAgIQAAgMgGgGQgFgHgMABQgJgBgHAHQgHAGAAAJIgeAAQAAgVAPgOQAPgMAXAAQAZAAAPAMQAOAOAAAWQAAAUgUAVIgPAOQgIAJgBASg");
	this.shape.setTransform(0.625,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgPBYQgEgFAAgGQAAgIAFgEQAEgEAIgBQAHABAFAEQAEAEAAAIQAAAGgEAFQgEAFgIAAQgIAAgFgFgAgRAmQAAgRAEgJQAEgLAMgLQAMgLADgFQAFgIAAgIQAAgMgGgGQgFgHgMABQgJgBgHAHQgHAGAAAJIgeAAQAAgVAPgOQAPgMAXAAQAZAAAPAMQAOAOAAAWQAAAUgUAVIgPAOQgIAJgBASg");
	this.shape_1.setTransform(0.625,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(2));

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ai2DDQgsAAAAguIAAkqQAAgtAsAAIFtAAQAsAAAAAtIAAEqQAAAugsAAg");
	this.shape_2.setTransform(0,-0.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF6600").s().p("Ai2DDQgsAAAAguIAAkqQAAgtAsAAIFtAAQAsAAAAAtIAAEqQAAAugsAAg");
	this.shape_3.setTransform(0,-0.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2}]}).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-413.4,-87.1,517,105.8);


// stage content:
(lib.Theeatwellplate = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,1];
	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		/* Click to Go to Frame and Stop
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and stops the movie.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		this.start_mc.addEventListener("click", fl_ClickToGoToAndStopAtFrame_10.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_10()
		{
			this.gotoAndStop(1);
		
		}
		
		/* Click to Go to Frame and Stop
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and stops the movie.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		this.reset_mc.addEventListener("click", fl_ClickToGoToAndStopAtFrame_11.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_11()
		{
			this.gotoAndStop(0);
		}
		this.fruitsandveg_mc.visible = false;
		this.fruitsandvegx.visible = false;
		this.breadrice_mc.visible = false;
		this.breadricex.visible = false;
		this.milkanddairy_mc.visible = false;
		this.milkanddairyx.visible = false;
		this.foodsanddrink_mc.visible = false;
		this.foodsanddrinkx.visible = false;
		this.meatfish_mc.visible = false;
		this.meatfishx.visible = false;
	}
	this.frame_1 = function() {
		/* Mouse Click Event
		Clicking on the specified symbol instance executes a function in which you can add your own custom code.
		
		Instructions:
		1. Add your custom code on a new line after the line that says "// Start your custom code" below.
		The code will execute when the symbol instance is clicked.
		*/
		
		this.fruitvegbtn.addEventListener("click", fl_MouseClickHandler_10.bind(this));
		
		function fl_MouseClickHandler_10()
		{
			this.fruitsandveg_mc.visible = true;
			this.fruitsandvegx.visible = true;
			this.fruitvegbtn.visible = false;
		this.breadricebtn.visible = false;
		this.milkanddairybtn.visible = false;
		this.foodsanddrinkbtn.visible = false;
		this.meatfishbtn.visible = false;
		}
		
		/* Mouse Click Event
		Clicking on the specified symbol instance executes a function in which you can add your own custom code.
		
		Instructions:
		1. Add your custom code on a new line after the line that says "// Start your custom code" below.
		The code will execute when the symbol instance is clicked.
		*/
		
		this.fruitsandvegx.addEventListener("click", fl_MouseClickHandler_11.bind(this));
		
		function fl_MouseClickHandler_11()
		{
		this.fruitsandveg_mc.visible = false;
		this.fruitsandvegx.visible = false;
				this.fruitvegbtn.visible = true;
		this.breadricebtn.visible = true;
		this.milkanddairybtn.visible = true;
		this.foodsanddrinkbtn.visible = true;
		this.meatfishbtn.visible = true;
		}
		
		/* Mouse Click Event
		Clicking on the specified symbol instance executes a function in which you can add your own custom code.
		
		Instructions:
		1. Add your custom code on a new line after the line that says "// Start your custom code" below.
		The code will execute when the symbol instance is clicked.
		*/
		
		this.meatfishbtn.addEventListener("click", fl_MouseClickHandler_12.bind(this));
		
		function fl_MouseClickHandler_12()
		{
		this.meatfish_mc.visible = true;
		this.meatfishx.visible = true;
			this.fruitvegbtn.visible = false;
		this.breadricebtn.visible = false;
		this.milkanddairybtn.visible = false;
		this.foodsanddrinkbtn.visible = false;
		this.meatfishbtn.visible = false;
		}
		
		/* Mouse Click Event
		Clicking on the specified symbol instance executes a function in which you can add your own custom code.
		
		Instructions:
		1. Add your custom code on a new line after the line that says "// Start your custom code" below.
		The code will execute when the symbol instance is clicked.
		*/
		
		this.meatfishx.addEventListener("click", fl_MouseClickHandler_13.bind(this));
		
		function fl_MouseClickHandler_13()
		{
		this.meatfish_mc.visible = false;
		this.meatfishx.visible = false;
				this.fruitvegbtn.visible = true;
		this.breadricebtn.visible = true;
		this.milkanddairybtn.visible = true;
		this.foodsanddrinkbtn.visible = true;
		this.meatfishbtn.visible = true;
		}
		
		/* Mouse Click Event
		Clicking on the specified symbol instance executes a function in which you can add your own custom code.
		
		Instructions:
		1. Add your custom code on a new line after the line that says "// Start your custom code" below.
		The code will execute when the symbol instance is clicked.
		*/
		
		this.foodsanddrinkbtn.addEventListener("click", fl_MouseClickHandler_14.bind(this));
		
		function fl_MouseClickHandler_14()
		{
		this.foodsanddrink_mc.visible = true;
		this.foodsanddrinkx.visible = true;
			this.fruitvegbtn.visible = false;
		this.breadricebtn.visible = false;
		this.milkanddairybtn.visible = false;
		this.foodsanddrinkbtn.visible = false;
		this.meatfishbtn.visible = false;
		}
		
		/* Mouse Click Event
		Clicking on the specified symbol instance executes a function in which you can add your own custom code.
		
		Instructions:
		1. Add your custom code on a new line after the line that says "// Start your custom code" below.
		The code will execute when the symbol instance is clicked.
		*/
		
		this.foodsanddrinkx.addEventListener("click", fl_MouseClickHandler_15.bind(this));
		
		function fl_MouseClickHandler_15()
		{
		this.foodsanddrink_mc.visible = false;
		this.foodsanddrinkx.visible = false;
				this.fruitvegbtn.visible = true;
		this.breadricebtn.visible = true;
		this.milkanddairybtn.visible = true;
		this.foodsanddrinkbtn.visible = true;
		this.meatfishbtn.visible = true;
		}
		
		/* Mouse Click Event
		Clicking on the specified symbol instance executes a function in which you can add your own custom code.
		
		Instructions:
		1. Add your custom code on a new line after the line that says "// Start your custom code" below.
		The code will execute when the symbol instance is clicked.
		*/
		
		this.breadricebtn.addEventListener("click", fl_MouseClickHandler_16.bind(this));
		
		function fl_MouseClickHandler_16()
		{
		this.breadrice_mc.visible = true;
		this.breadricex.visible = true;
			this.fruitvegbtn.visible = false;
		this.breadricebtn.visible = false;
		this.milkanddairybtn.visible = false;
		this.foodsanddrinkbtn.visible = false;
		this.meatfishbtn.visible = false;
		}
		
		/* Mouse Click Event
		Clicking on the specified symbol instance executes a function in which you can add your own custom code.
		
		Instructions:
		1. Add your custom code on a new line after the line that says "// Start your custom code" below.
		The code will execute when the symbol instance is clicked.
		*/
		
		this.breadricex.addEventListener("click", fl_MouseClickHandler_17.bind(this));
		
		function fl_MouseClickHandler_17()
		{
		this.breadrice_mc.visible = false;
		this.breadricex.visible = false;
				this.fruitvegbtn.visible = true;
		this.breadricebtn.visible = true;
		this.milkanddairybtn.visible = true;
		this.foodsanddrinkbtn.visible = true;
		this.meatfishbtn.visible = true;
		}
		
		/* Mouse Click Event
		Clicking on the specified symbol instance executes a function in which you can add your own custom code.
		
		Instructions:
		1. Add your custom code on a new line after the line that says "// Start your custom code" below.
		The code will execute when the symbol instance is clicked.
		*/
		
		this.milkanddairybtn.addEventListener("click", fl_MouseClickHandler_20.bind(this));
		
		function fl_MouseClickHandler_20()
		{
		this.milkanddairy_mc.visible = true;
		this.milkanddairyx.visible = true;
			this.fruitvegbtn.visible = false;
		this.breadricebtn.visible = false;
		this.milkanddairybtn.visible = false;
		this.foodsanddrinkbtn.visible = false;
		this.meatfishbtn.visible = false;
		}
		
		/* Mouse Click Event
		Clicking on the specified symbol instance executes a function in which you can add your own custom code.
		
		Instructions:
		1. Add your custom code on a new line after the line that says "// Start your custom code" below.
		The code will execute when the symbol instance is clicked.
		*/
		
		this.milkanddairyx.addEventListener("click", fl_MouseClickHandler_23.bind(this));
		
		function fl_MouseClickHandler_23()
		{
		this.milkanddairy_mc.visible = false;
		this.milkanddairyx.visible = false;
			this.fruitvegbtn.visible = true;
		this.breadricebtn.visible = true;
		this.milkanddairybtn.visible = true;
		this.foodsanddrinkbtn.visible = true;
		this.meatfishbtn.visible = true;
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// interface_buttons
	this.start_mc = new lib.startbutton();
	this.start_mc.name = "start_mc";
	this.start_mc.setTransform(627.85,514.65,1.487,1.487);
	new cjs.ButtonHelper(this.start_mc, 0, 1, 2);

	this.help_mc = new lib.helpbutton();
	this.help_mc.name = "help_mc";
	this.help_mc.setTransform(1107.15,737.3,1.487,1.487,0,0,0,0,0.1);
	new cjs.ButtonHelper(this.help_mc, 0, 1, 2);

	this.reset_mc = new lib.resetbutton();
	this.reset_mc.name = "reset_mc";
	this.reset_mc.setTransform(1201.35,738.3,1.487,1.487);
	new cjs.ButtonHelper(this.reset_mc, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.reset_mc},{t:this.help_mc},{t:this.start_mc}]}).to({state:[{t:this.reset_mc},{t:this.help_mc}]},1).wait(1));

	// border
	this.instance = new lib.border("synched",0);
	this.instance.setTransform(632.7,386.65,1.7386,1.7386);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({startPosition:0},0).wait(1));

	// Text
	this.instance_1 = new lib.CachedBmp_24();
	this.instance_1.setTransform(17.95,238.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},1).wait(1));

	// buttons
	this.breadricebtn = new lib.breadricebtn();
	this.breadricebtn.name = "breadricebtn";
	this.breadricebtn.setTransform(822.05,299.15,1,1,0,0,0,176.2,169.9);
	this.breadricebtn.compositeOperation = "overlay";
	new cjs.ButtonHelper(this.breadricebtn, 0, 1, 1);

	this.milkanddairybtn = new lib.milkanddairybtn();
	this.milkanddairybtn.name = "milkanddairybtn";
	this.milkanddairybtn.setTransform(796.7,471.45,1,1,0,0,0,156.8,125.7);
	this.milkanddairybtn.compositeOperation = "overlay";
	new cjs.ButtonHelper(this.milkanddairybtn, 0, 1, 1);

	this.foodsanddrinkbtn = new lib.foodsanddrinkbtn();
	this.foodsanddrinkbtn.name = "foodsanddrinkbtn";
	this.foodsanddrinkbtn.setTransform(637.95,477.45,1,1,0,0,0,73.5,124.7);
	this.foodsanddrinkbtn.compositeOperation = "overlay";
	new cjs.ButtonHelper(this.foodsanddrinkbtn, 0, 1, 1);

	this.meatfishbtn = new lib.meatfishbtn();
	this.meatfishbtn.name = "meatfishbtn";
	this.meatfishbtn.setTransform(498.95,474.95,1,1,0,0,0,147,122.2);
	this.meatfishbtn.compositeOperation = "overlay";
	new cjs.ButtonHelper(this.meatfishbtn, 0, 1, 1);

	this.fruitvegbtn = new lib.fruitvegbtn();
	this.fruitvegbtn.name = "fruitvegbtn";
	this.fruitvegbtn.setTransform(470.95,307.05,1,1,0,0,0,175,177.8);
	this.fruitvegbtn.compositeOperation = "overlay";
	new cjs.ButtonHelper(this.fruitvegbtn, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.fruitvegbtn},{t:this.meatfishbtn},{t:this.foodsanddrinkbtn},{t:this.milkanddairybtn},{t:this.breadricebtn}]},1).wait(1));

	// fruits and veg
	this.fruitsandvegx = new lib.fruitsandvegx();
	this.fruitsandvegx.name = "fruitsandvegx";
	this.fruitsandvegx.setTransform(1239.1,671.55,1,1,0,0,0,9.7,20);
	new cjs.ButtonHelper(this.fruitsandvegx, 0, 1, 1);

	this.fruitsandveg_mc = new lib.fruitsandveg();
	this.fruitsandveg_mc.name = "fruitsandveg_mc";
	this.fruitsandveg_mc.setTransform(640.85,365.7,1,1,0,0,0,617,325.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.fruitsandveg_mc},{t:this.fruitsandvegx}]},1).wait(1));

	// bread,rice
	this.breadricex = new lib.breadricex();
	this.breadricex.name = "breadricex";
	this.breadricex.setTransform(1237.15,660.95,1,1,0,0,0,9.7,20);
	new cjs.ButtonHelper(this.breadricex, 0, 1, 1);

	this.breadrice_mc = new lib.breadrice();
	this.breadrice_mc.name = "breadrice_mc";
	this.breadrice_mc.setTransform(640.85,365.7,1,1,0,0,0,617,325.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.breadrice_mc},{t:this.breadricex}]},1).wait(1));

	// milk and dairy
	this.milkanddairyx = new lib.milkanddairyx();
	this.milkanddairyx.name = "milkanddairyx";
	this.milkanddairyx.setTransform(1240.05,671.55,1,1,0,0,0,9.7,20);
	new cjs.ButtonHelper(this.milkanddairyx, 0, 1, 1);

	this.milkanddairy_mc = new lib.milkanddairy_mc();
	this.milkanddairy_mc.name = "milkanddairy_mc";
	this.milkanddairy_mc.setTransform(640.85,365.7,1,1,0,0,0,617,325.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.milkanddairy_mc},{t:this.milkanddairyx}]},1).wait(1));

	// foods and drink
	this.foodsanddrinkx = new lib.foodsanddrinkx();
	this.foodsanddrinkx.name = "foodsanddrinkx";
	this.foodsanddrinkx.setTransform(1240.05,671.55,1,1,0,0,0,9.7,20);
	new cjs.ButtonHelper(this.foodsanddrinkx, 0, 1, 1);

	this.foodsanddrink_mc = new lib.foodsanddrink_mc();
	this.foodsanddrink_mc.name = "foodsanddrink_mc";
	this.foodsanddrink_mc.setTransform(640.85,365.7,1,1,0,0,0,617,325.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.foodsanddrink_mc},{t:this.foodsanddrinkx}]},1).wait(1));

	// meat,fish
	this.meatfishx = new lib.meatfishx();
	this.meatfishx.name = "meatfishx";
	this.meatfishx.setTransform(1240,671.55,1,1,0,0,0,9.7,20);
	new cjs.ButtonHelper(this.meatfishx, 0, 1, 1);

	this.meatfish_mc = new lib.meatfish_mc();
	this.meatfish_mc.name = "meatfish_mc";
	this.meatfish_mc.setTransform(640.85,365.7,1,1,0,0,0,617,325.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.meatfish_mc},{t:this.meatfishx}]},1).wait(1));

	// picture
	this.instance_2 = new lib.Screenshot20220524180343();
	this.instance_2.setTransform(17.9,21,0.7977,0.7977);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).wait(1));

	// stageBackground
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("Ehljg+uMDLHAAAMAAAB9dMjLHAAAg");
	this.shape.setTransform(640,391.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EhljA+vMAAAh9dMDLHAAAMAAAB9dg");
	this.shape_1.setTransform(640,391.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(2));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(629,380.5,662,413.5);
// library properties:
lib.properties = {
	id: '0B2B3EBA4B645D45A7E84D318570440E',
	width: 1280,
	height: 783,
	fps: 60,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/CachedBmp_42.png?1653990814285", id:"CachedBmp_42"},
		{src:"images/CachedBmp_24.png?1653990814285", id:"CachedBmp_24"},
		{src:"images/The eatwell plate_atlas_1.png?1653990814243", id:"The eatwell plate_atlas_1"},
		{src:"images/The eatwell plate_atlas_2.png?1653990814244", id:"The eatwell plate_atlas_2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['0B2B3EBA4B645D45A7E84D318570440E'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;