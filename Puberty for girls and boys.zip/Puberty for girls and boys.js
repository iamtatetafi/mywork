(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Puberty for girls and boys_atlas_1", frames: [[1402,996,60,58],[1402,1056,60,58],[1402,624,60,60],[1402,1116,60,58],[1402,686,60,60],[1402,468,124,76],[1402,546,124,76],[1402,312,146,76],[1402,390,146,76],[1402,156,150,76],[1402,234,150,76],[0,1319,1820,158],[1402,0,163,76],[1402,78,163,76],[1402,1176,60,58],[1402,1236,60,58],[1402,748,60,60],[1464,624,60,58],[1402,810,60,60],[1464,684,60,58],[1464,744,60,58],[1402,872,60,60],[1464,804,60,58],[1402,934,60,60],[0,0,1400,1317]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_29 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_27 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_28 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_25 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_24 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_23 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_22 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_21 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_20 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_19 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_18 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_17 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_16 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_15 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_14 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_12 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_13 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_10 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_8 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_6 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_7 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_3 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_2 = function() {
	this.initialize(ss["Puberty for girls and boys_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_1 = function() {
	this.initialize(img.CachedBmp_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2494,374);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.yes = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#006600").s().p("AiPCTIgFADIgVghIgCgCIABAAIhWiEIAqgbIBVCEIFjjtIAfAjImNEIg");
	this.shape.setTransform(25.675,15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.yes, new cjs.Rectangle(0,0,51.4,30), null);


(lib.no = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AANAkIh8BSIgbgqIBxhKIhdhRIAhgmIBmBbIBfg+IAbAqIhSA1IBSBJIghAmg");
	this.shape.setTransform(13.925,11.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.no, new cjs.Rectangle(0,0,27.9,23.6), null);


(lib.mm1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_29();
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_28();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mm1, new cjs.Rectangle(0,0,30,30), null);


(lib.mh18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("AiLClIAAlJIEXAAIAAFJg");
	this.shape.setTransform(14,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mh18, new cjs.Rectangle(0,0,28,33), null);


(lib.mh17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("AkDC0IAAlnIIHAAIAAFng");
	this.shape.setTransform(26,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mh17, new cjs.Rectangle(0,0,52,36), null);


(lib.mh16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("AjqC0IAAlnIHVAAIAAFng");
	this.shape.setTransform(23.5,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mh16, new cjs.Rectangle(0,0,47,36), null);


(lib.mh15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("AkDCbIAAk1IIHAAIAAE1g");
	this.shape.setTransform(26,15.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mh15, new cjs.Rectangle(0,0,52,31), null);


(lib.mh14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("AkcClIAAlJII5AAIAAFJg");
	this.shape.setTransform(28.5,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mh14, new cjs.Rectangle(0,0,57,33), null);


(lib.mh13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("AjgClIAAlJIHBAAIAAFJg");
	this.shape.setTransform(22.5,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mh13, new cjs.Rectangle(0,0,45,33), null);


(lib.mh12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("AjbCgIAAk/IG3AAIAAE/g");
	this.shape.setTransform(22,16);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mh12, new cjs.Rectangle(0,0,44,32), null);


(lib.mh11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("AiuClIAAlJIFdAAIAAFJg");
	this.shape.setTransform(17.5,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mh11, new cjs.Rectangle(0,0,35,33), null);


(lib.mh10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("A13ClIAAlJMArvAAAIAAFJg");
	this.shape.setTransform(140,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mh10, new cjs.Rectangle(0,0,280,33), null);


(lib.mh9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("AliClIAAlJILFAAIAAFJg");
	this.shape.setTransform(35.5,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mh9, new cjs.Rectangle(0,0,71,33), null);


(lib.mh8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("A13ClIAAlJMArvAAAIAAFJg");
	this.shape.setTransform(140,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mh8, new cjs.Rectangle(0,0,280,33), null);


(lib.mh7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("A7uClIAAlJMA3dAAAIAAFJg");
	this.shape.setTransform(177.5,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mh7, new cjs.Rectangle(0,0,355,33), null);


(lib.mh6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("A9IClIAAlJMA6RAAAIAAFJg");
	this.shape.setTransform(186.5,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mh6, new cjs.Rectangle(0,0,373,33), null);


(lib.mh5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("A/oClIAAlJMA/RAAAIAAFJg");
	this.shape.setTransform(202.5,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mh5, new cjs.Rectangle(0,0,405,33), null);


(lib.mh4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("AifClIAAlJIE/AAIAAFJg");
	this.shape.setTransform(16,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mh4, new cjs.Rectangle(0,0,32,33), null);


(lib.mh3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("EglfAClIAAlJMBK/AAAIAAFJg");
	this.shape.setTransform(240,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mh3, new cjs.Rectangle(0,0,480,33), null);


(lib.mh2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("A1FClIAAlJMAqLAAAIAAFJg");
	this.shape.setTransform(135,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mh2, new cjs.Rectangle(0,0,270,33), null);


(lib.mh = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("A6jClIAAlJMA1HAAAIAAFJg");
	this.shape.setTransform(170,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mh, new cjs.Rectangle(0,0,340,33), null);


(lib.m = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_25();
	this.instance.setTransform(0,2,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_24();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_27();
	this.instance_2.setTransform(0,2,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_28();
	this.instance_3.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_3},{t:this.instance_2}]},1).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,30,31);


(lib.startbutton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {up:0,over:1,down:2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.CachedBmp_22();
	this.instance.setTransform(-15.2,-13.8,0.3362,0.3362);

	this.instance_1 = new lib.CachedBmp_23();
	this.instance_1.setTransform(-18.9,-14.3,0.3362,0.3362);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(2));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAwDDIljAAQgtAAAAgtIAAkrQAAgtAtAAIFjAAIEEAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape.setTransform(2.775,-1.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF6600").s().p("AkpDDQgtAAAAgtIAAkrQAAgtAtAAIJTAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_1.setTransform(3.125,-1.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF6600").s().p("AkfDDQgtAAAAgtIAAkrQAAgtAtAAII/AAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_2.setTransform(0.775,-1.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.5,-21,70.6,39);


(lib.solvebutton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"up":0,"over":1,"down":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.CachedBmp_20();
	this.instance.setTransform(-21.7,-13.8,0.3362,0.3362);

	this.instance_1 = new lib.CachedBmp_21();
	this.instance_1.setTransform(-22.7,-13.8,0.3362,0.3362);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(2));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAwDDIljAAQgtAAAAgtIAAkrQAAgtAtAAIFjAAIEEAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape.setTransform(2.775,-1.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF6600").s().p("AkpDDQgtAAAAgtIAAkrQAAgtAtAAIJTAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_1.setTransform(1.775,-1.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF6600").s().p("AkfDDQgtAAAAgtIAAkrQAAgtAtAAII/AAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_2.setTransform(0.775,-1.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.5,-21,70.6,39);


(lib.resetbutton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"up":0,"over":1,"down":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.CachedBmp_18();
	this.instance.setTransform(-22.45,-13.8,0.3362,0.3362);

	this.instance_1 = new lib.CachedBmp_19();
	this.instance_1.setTransform(-23.45,-13.8,0.3362,0.3362);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(2));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAwDDIljAAQgtAAAAgtIAAkrQAAgtAtAAIFjAAIEEAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape.setTransform(2.775,-1.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF6600").s().p("AkpDDQgtAAAAgtIAAkrQAAgtAtAAIJTAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_1.setTransform(1.775,-1.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF6600").s().p("AkfDDQgtAAAAgtIAAkrQAAgtAtAAII/AAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_2.setTransform(0.775,-1.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.5,-21,70.6,39);


(lib.helptext = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.instance = new lib.CachedBmp_17();
	this.instance.setTransform(-146.9,-21.05,0.3362,0.3362);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#393939").ss(2,1,1).p("EAwiAE4MhhDAAAIAApvMBhDAAAg");
	this.shape.setTransform(155.675,4.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EgwhAE4IAApvMBhDAAAIAAJvg");
	this.shape_1.setTransform(155.675,4.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.helptext, new cjs.Rectangle(-155.9,-27.6,623.2,64.5), null);


(lib.checkbutton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"up":0,"over":1,"down":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.CachedBmp_15();
	this.instance.setTransform(-24.6,-13.8,0.3361,0.3361);

	this.instance_1 = new lib.CachedBmp_16();
	this.instance_1.setTransform(-25.6,-13.8,0.3361,0.3361);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(2));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAwDDIljAAQgtAAAAgtIAAkrQAAgtAtAAIFjAAIEEAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape.setTransform(2.775,-1.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF6600").s().p("AkpDDQgtAAAAgtIAAkrQAAgtAtAAIJTAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_1.setTransform(1.775,-1.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF6600").s().p("AkfDDQgtAAAAgtIAAkrQAAgtAtAAII/AAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_2.setTransform(0.775,-1.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.5,-21,70.6,39);


(lib.fh18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF00FF").s().p("AikClIAAlJIFJAAIAAFJg");
	this.shape.setTransform(16.5,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fh18, new cjs.Rectangle(0,0,33,33), null);


(lib.fh17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF00FF").s().p("AizDDIAAmFIFnAAIAAGFg");
	this.shape.setTransform(18,19.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fh17, new cjs.Rectangle(0,0,36,39), null);


(lib.fh16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF00FF").s().p("AjHClIAAlJIGPAAIAAFJg");
	this.shape.setTransform(20,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fh16, new cjs.Rectangle(0,0,40,33), null);


(lib.fh15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF00FF").s().p("AkDCbIAAk1IIHAAIAAE1g");
	this.shape.setTransform(26,15.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fh15, new cjs.Rectangle(0,0,52,31), null);


(lib.fh14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF00FF").s().p("AkcD1IAAnpII5AAIAAHpg");
	this.shape.setTransform(28.5,24.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fh14, new cjs.Rectangle(0,0,57,49), null);


(lib.fh13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF00FF").s().p("AjlClIAAlJIHLAAIAAFJg");
	this.shape.setTransform(23,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fh13, new cjs.Rectangle(0,0,46,33), null);


(lib.fh12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF00FF").s().p("AjRClIAAlJIGjAAIAAFJg");
	this.shape.setTransform(21,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fh12, new cjs.Rectangle(0,0,42,33), null);


(lib.fh11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF00FF").s().p("AkXCWIAAkrIIvAAIAAErg");
	this.shape.setTransform(28,15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fh11, new cjs.Rectangle(0,0,56,30), null);


(lib.fh10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF00FF").s().p("A13ClIAAlJMArvAAAIAAFJg");
	this.shape.setTransform(140,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fh10, new cjs.Rectangle(0,0,280,33), null);


(lib.fh9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF00FF").s().p("AnQClIAAlJIOhAAIAAFJg");
	this.shape.setTransform(46.5,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fh9, new cjs.Rectangle(0,0,93,33), null);


(lib.fh8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF00FF").s().p("A13ClIAAlJMArvAAAIAAFJg");
	this.shape.setTransform(140,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fh8, new cjs.Rectangle(0,0,280,33), null);


(lib.fh7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF00FF").s().p("A7uClIAAlJMA3dAAAIAAFJg");
	this.shape.setTransform(177.5,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fh7, new cjs.Rectangle(0,0,355,33), null);


(lib.fh6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF00FF").s().p("A9IClIAAlJMA6RAAAIAAFJg");
	this.shape.setTransform(186.5,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fh6, new cjs.Rectangle(0,0,373,33), null);


(lib.fh5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF00FF").s().p("A/oClIAAlJMA/RAAAIAAFJg");
	this.shape.setTransform(202.5,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fh5, new cjs.Rectangle(0,0,405,33), null);


(lib.fh4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF00FF").s().p("AjMClIAAlJIGZAAIAAFJg");
	this.shape.setTransform(20.5,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fh4, new cjs.Rectangle(0,0,41,33), null);


(lib.fh3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF00FF").s().p("EglfAClIAAlJMBK/AAAIAAFJg");
	this.shape.setTransform(240,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fh3, new cjs.Rectangle(0,0,480,33), null);


(lib.fh2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF00FF").s().p("A1FClIAAlJMAqLAAAIAAFJg");
	this.shape.setTransform(135,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fh2, new cjs.Rectangle(0,0,270,33), null);


(lib.fh = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF00FF").s().p("A6jClIAAlJMA1HAAAIAAFJg");
	this.shape.setTransform(170,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fh, new cjs.Rectangle(0,0,340,33), null);


(lib.ff1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_14();
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_13();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ff1, new cjs.Rectangle(0,0,30,30), null);


(lib.f = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_10();
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_9();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_12();
	this.instance_2.setTransform(0,0,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_13();
	this.instance_3.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_3},{t:this.instance_2}]},1).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,30,30);


(lib.DL_WHITE_ORANGE = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF5F11").s().p("AgsETQgSgKgFgPQgCgFADgEQACgEAFAAIBsAAQAFAAACAEQADAEgCAFQgFAPgSAKQgRALgVAAQgXAAgRgLgACdDtQgJgBgGgHIgRgWQgGgHABgJQABgKAHgGQAHgGAKABQAJABAGAIIARAVQAGAIgBAJQgBAJgHAGQgGAFgIAAIgDAAgAjCDeQgHgGgBgKQAAgJAGgHIATgUQAGgHAJgBQAKgBAHAHQAHAGAAAKQABAJgGAHIgTAUQgGAHgKABIgBAAQgJAAgGgGgAg5DZQgIAAgGgFQgHgGgCgIIgCgKIAAAAQgGgVgRgWIgcggQgrgxAAhAQAAhHAxgyQAyg1BJAAQBHAAAyAzQAzAzAABIQAABAgrAxQgTAUgJAMQgRAWgGAVIAAAAIgEALQgCAIgGAFQgHAFgIAAgAhZhdQgmAjgCAzQgCAyAjApQAwA5AKAgIABAAIBBABIABgBQALgiAyg5QAfgkAAguQAAg0glgmQglglgzAAQgxAAgkAigACViHQgHgGABgKQAAgJAHgHIAUgTQAHgGAJAAQAJABAHAGQAHAHgBAJQAAAKgHAGIgUATQgHAHgJAAQgKgBgGgHgAi2iPIgTgTQgHgHABgKQAAgJAHgHQAHgGAJAAQAJAAAHAHIATAUQAGAHAAAJQAAAJgHAHQgHAHgJAAQgKgBgGgHgAgUjPQgHgHAAgJIAAgnQAAgKAHgGQAHgHAJAAQAJAAAGAHQAHAGAAAKIAAAnQAAAJgHAHQgGAHgJAAQgJAAgHgHg");
	this.shape.setTransform(62.1249,31.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAyDmQgpgWgXgqQgXgpAAg0QAAg4AYgrQAXgrAmgWQAlgXAtAAQArAAAmAWQAlAWAXAnQAYAnAAAwQAAAMgKAJQgKAIgNAAIjtAAQAEAxAhAeQAhAeAvAAQAhAAAUgJQAVgKAPgPQAKgGAJAAQAMAAAHAIQAJAIgBALQAAAPgNALQgTATghAOQggANgjAAQg3AAgogXgABAgiQgbAWgKArIDHAAIAAgFQgDgjgcgXQgdgXgkAAQgmAAgcAVgAnqDmQglgXgWgrQgWgqABg1QAAg1AUgpQAWgqAlgYQAkgXAuAAQAiAAAgAOQAeAPATAYIAAifQAAgNAJgKQAJgJAOAAQAOAAAKAJQAIAKABANIAAGyQgBAOgIAJQgKAKgOAAQgOAAgJgJQgJgKAAgOIAAgTQgQAYggASQgeAQgjAAQgvAAgkgXgAnIgnQgZARgOAbQgNAcAAAkQAAAkANAcQANAcAaARQAYAQAgAAQAhAAAXgQQAagRANgcQAOgcAAgkQAAgkgOgcQgNgbgagRQgXgQghAAQggAAgYAQgAtzDmQglgXgVgrQgWgqAAg1QAAg1AVgpQAVgpAlgZQAlgXAtAAQAjAAAfAOQAeAPAUAYIAAifQAAgOAJgJQAJgJANAAQAPAAAJAJQAJAKAAANIAAGyQAAAOgJAJQgJAKgPAAQgNAAgJgJQgJgJAAgPIAAgTQgRAYgfASQgeAQgkAAQgvAAgkgXgAtQgnQgaARgNAbQgOAcAAAkQAAAkAOAcQANAcAaARQAYAQAfAAQAhAAAYgQQAagRANgcQAOgcgBgkQABgkgOgcQgOgbgZgRQgYgQghAAQgfAAgYAQgAPEDlQgkgXgUgpQgUgoAAg0QAAgyAUgmQAVgpAjgWQAlgXArAAQAsAAAjAXQAkAYAPAmIAAg8QgBgGAEgEQADgEAHAAQAGAAADAEQAEAEABAGIAAE0QAAAFgFAEQgEAEgFAAQgGAAgEgEQgEgEABgFIAAg9QgSAjgiAXQgkAXgqAAQgtAAgjgXgAPTg4QgeATgRAiQgSAjABApQgBAqASAlQARAkAdASQAeAUAlAAQAmAAAegUQAdgTARgjQARgjAAgsQAAgpgRghQgRgigdgUQgfgUglAAQgkAAgeATgAJtDmQgngVgWgoQgWgoAAg0QAAg1AVgpQAVgoAkgWQAjgWAnAAQAoAAAiASQAhAQAXAjQAVAhACAzQAAAGgFAEQgDAEgGAAIkJAAIAAAJQABAqARAiQAQAjAhAUQAgAUAvAAQAiAAAbgPQAegRAPgYQAFgGAHAAQAEAAAEAEQAEAFAAADQgBAFgDAEQgVAegiASQggATgnAAQgzAAgmgWgAJ/g9QgaAOgTAZQgUAagHAkID4AAIAAgGQgDgigTgYQgSgYgcgNQgcgNgdAAQgYAAgbANgAiODtQgJgJAAgOIAAmyQAAgNAJgKQAKgJANAAQANAAAKAJQAJAKAAANIAAGyQAAAOgKAJQgJAKgNAAQgOAAgJgKgA7cD3QgNAAgJgKQgKgJAAgOIAAmXQAAgNAKgKQAJgJANAAICnAAQA/AAAuAgQAtAgAWA1QAYA1AABBQAABDgYA1QgWA1gtAgQguAgg/AAgA65C5IB9AAQBFAAAigxQAigyAAhMQAAhKgigyQgjgxhEAAIh9AAgAblDxQgDgEAAgFIAAjMQAAgsgYgeQgYgdgxAAQgdAAgcAOQgeAPgRAXQgTAYABAbIAADMQAAAEgFAFQgEAEgFAAQgGAAgEgEQgEgEABgFIAAk0QAAgGADgEQAEgEAGAAQAGAAADAEQAFAEAAAGIAAAtQAUgfAjgTQAjgUAkAAQA7AAAfAkQAeAjAAA4IAADOQAAAEgEAFQgFAEgEAAQgGAAgFgEgAUODxQgEgEAAgFIAAk0QAAgGAEgEQAEgEAFAAQAGAAAEAEQAEAEAAAGIAABHQAPgpAhgbQAhgbAsgBQAfAAAAAQQAAAGgDAEQgDAEgGAAIgKgDQgIgDgIAAQgbAAgcAWQgcAWgRAhQgSAfAAAgIAACpQAAAFgFAEQgEAEgFAAQgFAAgEgEgAHFDxQgFgFAAgEIAAnXQAAgEAFgFQAFgEAEAAQAGAAAEAEQADAEAAAFIAAHXQAAAFgDAEQgEAEgGAAQgFAAgEgEg");
	this.shape_1.setTransform(178.9,25.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.DL_WHITE_ORANGE, new cjs.Rectangle(0,0,357.8,59.9), null);


(lib.bh = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF00").s().p("A6jClIAAlJMA1HAAAIAAFJg");
	this.shape.setTransform(170,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bh, new cjs.Rectangle(0,0,340,33), null);


(lib.bb1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_8();
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_7();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bb1, new cjs.Rectangle(0,0,30,30), null);


(lib.b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_4();
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_3();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_6();
	this.instance_2.setTransform(0,0,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_7();
	this.instance_3.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_3},{t:this.instance_2}]},1).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,30,30);


(lib.helpbutton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"up":0,"over":1,"down":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.helptext();
	this.instance.setTransform(-136.6,-73.65,1,1,0,0,0,66.2,-6.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(2));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AgPBYQgEgFAAgGQAAgIAFgEQAEgEAIgBQAHABAFAEQAEAEAAAIQAAAGgEAFQgEAFgIAAQgIAAgFgFgAgRAmQAAgRAEgJQAEgLAMgLQAMgLADgFQAFgIAAgIQAAgMgGgGQgFgHgMABQgJgBgHAHQgHAGAAAJIgeAAQAAgVAPgOQAPgMAXAAQAZAAAPAMQAOAOAAAWQAAAUgUAVIgPAOQgIAJgBASg");
	this.shape.setTransform(0.625,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgPBYQgEgFAAgGQAAgIAFgEQAEgEAIgBQAHABAFAEQAEAEAAAIQAAAGgEAFQgEAFgIAAQgIAAgFgFgAgRAmQAAgRAEgJQAEgLAMgLQAMgLADgFQAFgIAAgIQAAgMgGgGQgFgHgMABQgJgBgHAHQgHAGAAAJIgeAAQAAgVAPgOQAPgMAXAAQAZAAAPAMQAOAOAAAWQAAAUgUAVIgPAOQgIAJgBASg");
	this.shape_1.setTransform(0.625,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(2));

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ai2DDQgsAAAAguIAAkqQAAgtAsAAIFtAAQAsAAAAAtIAAEqQAAAugsAAg");
	this.shape_2.setTransform(0,-0.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF6600").s().p("Ai2DDQgsAAAAguIAAkqQAAgtAsAAIFtAAQAsAAAAAtIAAEqQAAAugsAAg");
	this.shape_3.setTransform(0,-0.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2}]}).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-358.7,-95,623.2,113.7);


(lib.border = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.DL_WHITE_ORANGE();
	this.instance.setTransform(-269.05,203.9,0.4521,0.4521,0,0,0,178.8,29.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("Eg39AjNQhjAAAAhjMAAAhDTQAAhjBjAAMBv7AAAQBjAAAABjMAAABDTQAABjhjAAgEg39AbUMBotAAAIHOAAMAAAg7QInOAAMhotAAAg");
	this.shape.setTransform(4.05,2.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-364,-222.7,736.2,450.6);


// stage content:
(lib.Pubertyforgirlsandboys = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.mh1.visible = false;
		this.mm1.visible = false;
		this.fh1.visible = false;
		this.ff1.visible = false;
		this.bh1.visible = false;
		this.bb1.visible = false;
		this.yes1.visible = false;
		this.no1.visible = false;
		this.mh2.visible = false;
		this.mm2.visible = false;
		this.fh2.visible = false;
		this.ff2.visible = false;
		this.bh2.visible = false;
		this.bb2.visible = false;
		this.yes2.visible = false;
		this.no2.visible = false;
		this.mh3.visible = false;
		this.mm3.visible = false;
		this.ff3.visible = false;
		this.fh3.visible = false;
		this.bh3.visible = false;
		this.bb3.visible = false;
		this.yes3.visible = false;
		this.no3.visible = false;
		this.mh4.visible = false;
		this.mm4.visible = false;
		this.fh4.visible = false;
		this.ff4.visible = false;
		this.bh4.visible = false;
		this.bb4.visible = false;
		this.yes4.visible = false;
		this.no4.visible = false;
		this.mh5.visible = false;
		this.mm5.visible = false;
		this.ff5.visible = false;
		this.fh5.visible = false;
		this.bh5.visible = false;
		this.bb5.visible = false;
		this.yes5.visible = false;
		this.no5.visible = false;
		this.mm6.visible = false;
		this.mh6.visible = false;
		this.fh6.visible = false;
		this.ff6.visible = false;
		this.bh6.visible = false;
		this.bb6.visible = false;
		this.yes6.visible = false;
		this.no6.visible = false;
		this.mh7.visible = false;
		this.mm7.visible = false;
		this.fh7.visible = false;
		this.ff7.visible = false;
		this.bh7.visible = false;
		this.bb7.visible = false;
		this.yes7.visible = false;
		this.no7.visible = false;
		this.mh8.visible = false;
		this.mm8.visible = false;
		this.fh8.visible = false;
		this.ff8.visible = false;
		this.bh8.visible = false;
		this.bb8.visible = false;
		this.yes8.visible = false;
		this.no8.visible = false;
		this.mh9.visible = false;
		this.mm9.visible = false;
		this.fh9.visible = false;
		this.ff9.visible = false;
		this.bh9.visible = false;
		this.bb9.visible = false;
		this.yes9.visible = false;
		this.no9.visible = false;
		this.mh10.visible = false;
		this.fh10.visible = false;
		this.mm10.visible = false;
		this.ff10.visible = false;
		this.bh10.visible = false;
		this.bb10.visible = false;
		this.yes10.visible = false;
		this.no10.visible = false;
		this.mh11.visible = false;
		this.fh11.visible = false;
		this.mm11.visible = false;
		this.ff11.visible = false;
		this.bh11.visible = false;
		this.bb11.visible = false;
		this.yes11.visible = false;
		this.no11.visible = false;
		this.mh12.visible = false;
		this.fh12.visible = false;
		this.mm12.visible = false;
		this.ff12.visible = false;
		this.bh12.visible = false;
		this.bb12.visible = false;
		this.yes12.visible = false;
		this.no12.visible = false;
		this.mh13.visible = false;
		this.fh13.visible = false;
		this.mm13.visible = false;
		this.ff13.visible = false;
		this.bh13.visible = false;
		this.bb13.visible = false;
		this.yes13.visible = false;
		this.no13.visible = false;
		this.mh14.visible = false;
		this.fh14.visible = false;
		this.mm14.visible = false;
		this.ff14.visible = false;
		this.bh14.visible = false;
		this.bb14.visible = false;
		this.yes14.visible = false;
		this.no14.visible = false;
		this.mh15.visible = false;
		this.mm15.visible = false;
		this.fh15.visible = false;
		this.ff15.visible = false;
		this.bh15.visible = false;
		this.bb15.visible = false;
		this.yes15.visible = false;
		this.no15.visible = false;
		this.mh16.visible = false;
		this.fh16.visible = false;
		this.mm16.visible = false;
		this.ff16.visible = false;
		this.bh16.visible = false;
		this.bb16.visible = false;
		this.yes16.visible = false;
		this.no16.visible = false;
		this.mh17.visible = false;
		this.fh17.visible = false;
		this.mm17.visible = false;
		this.ff17.visible = false;
		this.bh17.visible = false;
		this.bb17.visible = false;
		this.yes17.visible = false;
		this.no17.visible = false;
		this.mh18.visible = false;
		this.fh18.visible = false;
		this.mm18.visible = false;
		this.ff18.visible = false;
		this.bh18.visible = false;
		this.bb18.visible = false;
		this.yes18.visible = false;
		this.no18.visible = false;
		
		
		//start button
		this.start_mc.addEventListener("click", fl_ClickToGoToAndStopAtFrame_10.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_10()
		{
			this.gotoAndStop(1);
		
		}
		
		//solve button
		this.solve_mc.addEventListener("click", fl_MouseClickHandler_56.bind(this));
		
		function fl_MouseClickHandler_56()
		{
			this.bh1.visible = true;
			this.bb1.visible = true;
			this.mh1.visible = false;
			this.mm1.visible = false;
			this.fh1.visible = false;
			this.ff1.visible = false
			
			this.fh2.visible = true;
			this.ff2.visible = true;
			this.mh2.visible = false;
			this.mm2.visible = false;
			this.bh2.visible = false;
			this.bb2.visible = false;
			
			this.bh3.visible = true;
		    this.bb3.visible = true;
			this.mh3.visible = false;
			this.mm3.visible = false;
			this.fh3.visible = false;
			this.ff3.visible = false;
			
		    this.fh4.visible = true;
			this.ff4.visible = true;
			this.mh4.visible = false;
			this.mm4.visible = false;
			this.bh4.visible = false;
			this.bb4.visible = false;
			
			this.mh5.visible = true;
		    this.mm5.visible = true;
			this.fh5.visible = false;
			this.ff5.visible = false;
			this.bh5.visible = false;
			this.bb5.visible = false;
			
			this.bh6.visible = true;
		    this.bb6.visible = true;
			this.mh6.visible = false;
			this.mm6.visible = false;
			this.fh6.visible = false;
			this.ff6.visible = false;
			
			this.mh7.visible = true;
		    this.mm7.visible = true;
			this.fh7.visible = false;
			this.ff7.visible = false;
			this.bh7.visible = false;
			this.bb7.visible = false;
			
			this.fh8.visible = true;
			this.ff8.visible = true;
			this.mh8.visible = false;
			this.mm8.visible = false;
			this.bh8.visible = false;
			this.bb8.visible = false;
			
			this.mh9.visible = true;
			this.mm9.visible = true;
			this.fh9.visible = false;
			this.ff9.visible = false;
			this.bh9.visible = false;
			this.bb9.visible = false;
			
			this.mh10.visible = true;
			this.mm10.visible = true;
			this.fh10.visible = false;
			this.ff10.visible = false;
			this.bh10.visible = false;
			this.bb10.visible = false;
			
			this.bh11.visible = true;
			this.bb11.visible = true;
			this.mh11.visible = false;
			this.mm11.visible = false;
			this.fh11.visible = false;
			this.ff11.visible = false;
			
			this.bh12.visible = true;
		    this.bb12.visible = true;
			this.mh12.visible = false;
			this.mm12.visible = false;
			this.fh12.visible = false;
			this.ff12.visible = false;
			
			this.bh13.visible = true;
		    this.bb13.visible = true;
			this.mh13.visible = false;
			this.mm13.visible = false;
			this.fh13.visible = false;
			this.ff13.visible = false;
			
			this.bh14.visible = true;
		    this.bb14.visible = true;
			this.mh14.visible = false;
			this.mm14.visible = false;
			this.fh14.visible = false;
			this.ff14.visible = false;
			
			this.bh15.visible = true;
		    this.bb15.visible = true;
			this.mh15.visible = false;
			this.mm15.visible = false;
			this.fh15.visible = false;
			this.ff15.visible = false;
			
			this.fh16.visible = true;
		    this.ff16.visible = true;
			this.mh16.visible = false;
			this.mm16.visible = false;
			this.bh16.visible = false;
			this.bb16.visible = false;
			
			this.bh17.visible = true;
		    this.bb17.visible = true;
			this.mh17.visible = false;
			this.mm17.visible = false;
			this.fh17.visible = false;
			this.ff17.visible = false;
			
			this.fh18.visible = true;
		    this.ff18.visible = true;
			this.mh18.visible = false;
			this.mm18.visible = false;
			this.bh18.visible = false;
			this.bb18.visible = false;
			
			this.yes1.visible = false;
		this.no1.visible = false;
		this.yes2.visible = false;
		this.no2.visible = false;
		this.yes3.visible = false;
		this.no3.visible = false;
		this.yes4.visible = false;
		this.no4.visible = false;
		this.yes5.visible = false;
		this.no5.visible = false;
		this.yes6.visible = false;
		this.no6.visible = false;
		this.yes7.visible = false;
		this.no7.visible = false;
		this.yes8.visible = false;
		this.no8.visible = false;
		this.yes9.visible = false;
		this.no9.visible = false;
		this.yes10.visible = false;
		this.no10.visible = false;
		this.yes11.visible = false;
		this.no11.visible = false;
		this.yes12.visible = false;
		this.no12.visible = false;
		this.yes13.visible = false;
		this.no13.visible = false;
		this.yes14.visible = false;
		this.no14.visible = false;
		this.yes15.visible = false;
		this.no15.visible = false;
		this.yes16.visible = false;
		this.no16.visible = false;
		this.yes17.visible = false;
		this.no17.visible = false;
		this.yes18.visible = false;
		this.no18.visible = false;
			
		this.check_mc.visible = false;
		this.solve_mc.visible = false;
		}
		
		//check button
		this.check_mc.addEventListener("click", fl_MouseClickHandler_57.bind(this));
		
		function fl_MouseClickHandler_57()
		{
		if (this.bb1.visible){
				this.yes1.visible = true;		
		} 
		else {this.no1.visible = true;
			this.yes1.visible = false;
		}
		if (this.ff2.visible){
			this.yes2.visible = true
		}
		else {this.no2.visible = true;
			this.yes2.visible = false;
		}
		if (this.bb3.visible){
				this.yes3.visible = true;		
		} 
		else {this.no3.visible = true;
			this.yes3.visible = false;
		}
		if (this.ff4.visible){
			this.yes4.visible = true;
		}
		else {this.no4.visible = true;
			this.yes4.visible = false;
		}
		if (this.mm5.visible){
			this.yes5.visible = true
		}
		else {this.no5.visible = true;
			this.yes5.visible = false;
		}
		if (this.bb6.visible){
			this.yes6.visible = true;
		}
		else {this.no6.visible = true;
			 this.yes6.visible = false;
		}
		if (this.mm7.visible){
			this.yes7.visible = true;		
		} 
		else {this.no7.visible = true;
			this.yes7.visible = false;
		}
		if (this.ff8.visible){
			this.yes8.visible = true
		}
		else {this.no8.visible = true;
			this.yes8.visible = false;
		}
		if (this.mm9.visible){
			this.yes9.visible = true;
		}
		else {this.no9.visible = true;
			this.yes9.visible = false;
		}
		if (this.mm10.visible){
			this.yes10.visible = true;
		}
		else {this.no10.visible = true;
			this.yes10.visible = false;
		}
		if (this.bb11.visible){
			this.yes11.visible = true;
		}
		else {this.no11.visible = true;
			this.yes11.visible = false;
		}
		if (this.bb12.visible){
			this.yes12.visible = true;
		}
		else {this.no12.visible = true;
			this.yes12.visible = false;
		}
		if (this.bb13.visible){
			this.yes13.visible = true;
		}
		else {this.no13.visible = true;
			this.yes13.visible = false;
		}
		if (this.bb14.visible){
			this.yes14.visible = true;
		}
		else {this.no14.visible = true;
			this.yes14.visible = false;
		}
		if (this.bb15.visible){
			this.yes15.visible = true;
		}
		else {this.no15.visible = true;
			this.yes15.visible = false;
		}
		if (this.ff16.visible){
			this.yes16.visible = true;
		}
		else {this.no16.visible = true;
			this.yes16.visible = false;
		}
		if (this.bb17.visible){
			this.yes17.visible = true;
		}
		else {this.no17.visible = true;
			this.yes17.visible = false;
		}
		if (this.ff18.visible){
			this.yes18.visible = true;
		}
		else {this.no18.visible = true;
			this.yes18.visible = false;
		}
		this.check_mc.visible = false;
		this.solve_mc.visible = false;
		}
		
		//reset button
		this.reset_mc.addEventListener("click", fl_ClickToGoToAndStopAtFrame_11.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_11()
		{
			this.gotoAndStop(0);
			this.check_mc.visible = true;
		    this.solve_mc.visible = true;
		}
		
		//answer buttons
		this.m1.addEventListener("click", fl_MouseClickHandler.bind(this));
		
		function fl_MouseClickHandler()
		{
			this.mh1.visible = true;
			this.mm1.visible = true;
			this.bh1.visible = false;
			this.bb1.visible = false;
			this.fh1.visible = false;
			this.ff1.visible = false;
		}
		this.b1.addEventListener("click", fl_MouseClickHandler_3.bind(this));
		
		function fl_MouseClickHandler_3()
		{
			this.bh1.visible = true;
			this.bb1.visible = true;
			this.mh1.visible = false;
			this.mm1.visible = false;
			this.fh1.visible = false;
			this.ff1.visible = false;
			
		}
		
		
		this.f1.addEventListener("click", fl_MouseClickHandler_4.bind(this));
		
		function fl_MouseClickHandler_4()
		{
			this.fh1.visible = true;
			this.ff1.visible = true;
			this.bb1.visible = false;
			this.mh1.visible = false;
			this.mm1.visible = false;
			this.bh1.visble = false;
			
		}
		
		this.m2.addEventListener("click", fl_MouseClickHandler_5.bind(this));
		
		function fl_MouseClickHandler_5()
		{
			this.mh2.visible = true;
			this.mm2.visible = true;
			this.bh2.visible = false;
			this.bb2.visible = false;
			this.fh2.visible = false;
			this.ff2.visible = false;
		}
		this.f2.addEventListener("click", fl_MouseClickHandler_6.bind(this));
		
		function fl_MouseClickHandler_6()
		{
			this.fh2.visible = true;
			this.ff2.visible = true;
			this.mh2.visible = false;
			this.mm2.visible = false;
			this.bh2.visible = false;
			this.bb2.visible = false;
		}
		this.b2.addEventListener("click", fl_MouseClickHandler_7.bind(this));
		
		function fl_MouseClickHandler_7()
		{
			this.bh2.visible = true;
			this.bb2.visible = true;
			this.mh2.visible = false;
			this.fh2.visible = false;
			this.mm2.visible = false;
			this.ff2.visible = false;
		}
		
		this.m3.addEventListener("click", fl_MouseClickHandler_8.bind(this));
		
		function fl_MouseClickHandler_8()
		{
			this.mh3.visible = true;
			this.mm3.visible = true;
			this.bh3.visible = false;
			this.fh3.visible = false;
			this.bb3.visible = false;
			this.ff3.visible = false;
		}
		this.f3.addEventListener("click", fl_MouseClickHandler_9.bind(this));
		
		function fl_MouseClickHandler_9()
		{
			this.fh3.visible = true;
			this.mh3.visible = false;
			this.bh3.visible = false;
			this.ff3.visible = true;
			this.mm3.visible = false;
			this.bb3.visible = false;
		}
		this.b3.addEventListener("click", fl_MouseClickHandler_10.bind(this));
		
		function fl_MouseClickHandler_10()
		{
			this.bh3.visible = true;
			this.mh3.visible = false;
			this.fh3.visible = false;
			this.bb3.visible = true;
			this.mm3.visible = false;
			this.ff3.visible = false;
			
		}
		
		this.m4.addEventListener("click", fl_MouseClickHandler_11.bind(this));
		
		function fl_MouseClickHandler_11()
		{
			this.mh4.visible = true;
			this.bh4.visible = false;
			this.fh4.visible = false;
			this.mm4.visible = true;
			this.bb4.visible = false;
			this.ff4.visible = false;
		}
		this.f4.addEventListener("click", fl_MouseClickHandler_12.bind(this));
		
		function fl_MouseClickHandler_12()
		{
			this.fh4.visible = true;
			this.mh4.visible = false;
			this.bh4.visible = false;
			this.ff4.visible = true;
			this.mm4.visible = false;
			this.bb4.visible = false;
		}
		this.b4.addEventListener("click", fl_MouseClickHandler_13.bind(this));
		
		function fl_MouseClickHandler_13()
		{
			this.bh4.visible = true;
			this.mh4.visible = false;
			this.fh4.visible = false;
			this.bb4.visible = true;
			this.mm4.visible = false;
			this.ff4.visible = false;
			
		}
		
		this.m5.addEventListener("click", fl_MouseClickHandler_14.bind(this));
		
		function fl_MouseClickHandler_14()
		{
			this.mh5.visible = true;
			this.bh5.visible = false;
			this.fh5.visible = false;
			this.mm5.visible = true;
			this.bb5.visible = false;
			this.ff5.visible = false;
		}
		
		this.f5.addEventListener("click", fl_MouseClickHandler_15.bind(this));
		
		function fl_MouseClickHandler_15()
		{
			this.fh5.visible = true;
			this.mh5.visible = false;
			this.bh5.visible = false;
			this.ff5.visible = true;
			this.mm5.visible = false;
			this.bb5.visible = false;
		}
		
		this.b5.addEventListener("click", fl_MouseClickHandler_16.bind(this));
		
		function fl_MouseClickHandler_16()
		{
			this.bh5.visible = true;
			this.mh5.visible = false;
			this.fh5.visible = false;
			this.bb5.visible = true;
			this.mm5.visible = false;
			this.ff5.visible = false;
			
		}
		
		this.m6.addEventListener("click", fl_MouseClickHandler_17.bind(this));
		
		function fl_MouseClickHandler_17()
		{
			this.mh6.visible = true;
			this.bh6.visible = false;
			this.fh6.visible = false;
			this.mm6.visible = true;
			this.bb6.visible = false;
			this.ff6.visible = false;
		}
		
		this.f6.addEventListener("click", fl_MouseClickHandler_18.bind(this));
		
		function fl_MouseClickHandler_18()
		{
			this.fh6.visible = true;
			this.mh6.visible = false;
			this.bh6.visible = false;
			this.ff6.visible = true;
			this.mm6.visible = false;
			this.bb6.visible = false;
		}
		
		this.b6.addEventListener("click", fl_MouseClickHandler_19.bind(this));
		
		function fl_MouseClickHandler_19()
		{
			this.bh6.visible = true;
			this.mh6.visible = false;
			this.fh6.visible = false;
			this.bb6.visible = true;
			this.mm6.visible = false;
			this.ff6.visible = false;
		}
		this.m7.addEventListener("click", fl_MouseClickHandler_20.bind(this));
		
		function fl_MouseClickHandler_20()
		{
			this.mh7.visible = true;
			this.bh7.visible = false;
			this.fh7.visible = false;
			this.mm7.visible = true;
			this.bb7.visible = false;
			this.ff7.visible = false;
		}
		
		this.f7.addEventListener("click", fl_MouseClickHandler_21.bind(this));
		
		function fl_MouseClickHandler_21()
		{
			this.fh7.visible = true;
			this.mh7.visible = false;
			this.bh7.visible = false;
			this.ff7.visible = true;
			this.mm7.visible = false;
			this.bb7.visible = false;
		}
		
		this.b7.addEventListener("click", fl_MouseClickHandler_22.bind(this));
		
		function fl_MouseClickHandler_22()
		{
			this.bh7.visible = true;
			this.mh7.visible = false;
			this.fh7.visible = false;
			this.bb7.visible = true;
			this.mm7.visible = false;
			this.ff7.visible = false;
			
		}
		
		this.m8.addEventListener("click", fl_MouseClickHandler_23.bind(this));
		
		function fl_MouseClickHandler_23()
		{
			this.mh8.visible = true;
			this.bh8.visible = false;
			this.fh8.visible = false;
			this.mm8.visible = true;
			this.bb8.visible = false;
			this.ff8.visible = false;
		}
		
		this.f8.addEventListener("click", fl_MouseClickHandler_24.bind(this));
		
		function fl_MouseClickHandler_24()
		{
			this.fh8.visible = true;
			this.mh8.visible = false;
			this.bh8.visible = false;
			this.ff8.visible = true;
			this.mm8.visible = false;
			this.bb8.visible = false;
		}
		
		this.b8.addEventListener("click", fl_MouseClickHandler_25.bind(this));
		
		function fl_MouseClickHandler_25()
		{
			this.bh8.visible = true;
			this.mh8.visible = false;
			this.fh8.visible = false;
			this.bb8.visible = true;
			this.mm8.visible = false;
			this.ff8.visible = false;
		}
		
		this.m9.addEventListener("click", fl_MouseClickHandler_26.bind(this));
		
		function fl_MouseClickHandler_26()
		{
			this.mh9.visible = true;
			this.fh9.visible = false;
			this.bh9.visible = false;
			this.mm9.visible = true;
			this.bb9.visible = false;
			this.ff9.visible = false;
		}
		
		this.f9.addEventListener("click", fl_MouseClickHandler_27.bind(this));
		
		function fl_MouseClickHandler_27()
		{
			this.fh9.visible = true;
			this.mh9.visible = false;
			this.bh9.visible = false;
			this.ff9.visible = true;
			this.mm9.visible = false;
			this.bb9.visible = false;
		}
		
		this.b9.addEventListener("click", fl_MouseClickHandler_28.bind(this));
		
		function fl_MouseClickHandler_28()
		{
			this.bh9.visible = true;
			this.mh9.visible = false;
			this.fh9.visible = false;
			this.bb9.visible = true;
			this.mm9.visible = false;
			this.ff9.visible = false;
			
		}
		
		this.m10.addEventListener("click", fl_MouseClickHandler_29.bind(this));
		
		function fl_MouseClickHandler_29()
		{
			this.mh10.visible = true;
			this.bh10.visible = false;
			this.fh10.visible = false;
			this.mm10.visible = true;
			this.bb10.visible = false;
			this.ff10.visible = false;
		}
		
		this.f10.addEventListener("click", fl_MouseClickHandler_30.bind(this));
		
		function fl_MouseClickHandler_30()
		{
			this.fh10.visible = true;
			this.mh10.visible = false;
			this.bh10.visible = false;
			this.ff10.visible = true;
			this.mm10.visible = false;
			this.bb10.visible = false;
		}
		
		this.b10.addEventListener("click", fl_MouseClickHandler_31.bind(this));
		
		function fl_MouseClickHandler_31()
		{
			this.bh10.visible = true;
			this.mh10.visible = false;
			this.fh10.visible = false;
			this.bb10.visible = true;
			this.mm10.visible = false;
			this.ff10.visible = false;
		}
		
		this.m11.addEventListener("click", fl_MouseClickHandler_32.bind(this));
		
		function fl_MouseClickHandler_32()
		{
			this.mh11.visible = true;
			this.bh11.visible = false;
			this.fh11.visible = false;
			this.mm11.visible = true;
			this.bb11.visible = false;
			this.ff11.visible = false;
		}
		
		this.f11.addEventListener("click", fl_MouseClickHandler_33.bind(this));
		
		function fl_MouseClickHandler_33()
		{
			this.fh11.visible = true;
			this.mh11.visible = false;
			this.bh11.visible = false;
			this.ff11.visible = true;
			this.mm11.visible = false;
			this.bb11.visible = false;
		}
		
		this.b11.addEventListener("click", fl_MouseClickHandler_34.bind(this));
		
		function fl_MouseClickHandler_34()
		{
			this.bh11.visible = true;
			this.mh11.visible = false;
			this.fh11.visible = false;
			this.bb11.visible = true;
			this.mm11.visible = false;
			this.ff11.visible = false;
			
		}
		
		this.m12.addEventListener("click", fl_MouseClickHandler_35.bind(this));
		
		function fl_MouseClickHandler_35()
		{
			this.mh12.visible = true;
			this.bh12.visible = false;
			this.fh12.visible = false;
			this.mm12.visible = true;
			this.bb12.visible = false;
			this.ff12.visible = false;
		}
		
		this.f12.addEventListener("click", fl_MouseClickHandler_36.bind(this));
		
		function fl_MouseClickHandler_36()
		{
			this.fh12.visible = true;
			this.mh12.visible = false;
			this.bh12.visible = false;
			this.ff12.visible = true;
			this.mm12.visible = false;
			this.bb12.visible = false;
		}
		
		this.b12.addEventListener("click", fl_MouseClickHandler_37.bind(this));
		
		function fl_MouseClickHandler_37()
		{
			this.bh12.visible = true;
			this.mh12.visible = false;
			this.fh12.visible = false;
			this.bb12.visible = true;
			this.mm12.visible = false;
			this.ff12.visible = false;
			
		}
		
		this.m13.addEventListener("click", fl_MouseClickHandler_38.bind(this));
		
		function fl_MouseClickHandler_38()
		{
			this.mh13.visible = true;
			this.bh13.visible = false;
			this.fh13.visible = false;
			this.mm13.visible = true;
			this.bb13.visible = false;
			this.ff13.visible = false;
		}
		
		this.f13.addEventListener("click", fl_MouseClickHandler_39.bind(this));
		
		function fl_MouseClickHandler_39()
		{
			this.fh13.visible = true;
			this.mh13.visible = false;
			this.bh13.visible = false;
			this.ff13.visible = true;
			this.mm13.visible = false;
			this.bb13.visible = false;
		}
		
		this.b13.addEventListener("click", fl_MouseClickHandler_40.bind(this));
		
		function fl_MouseClickHandler_40()
		{
			this.bh13.visible = true;
			this.mh13.visible = false;
			this.fh13.visible = false;
			this.bb13.visible = true;
			this.mm13.visible = false;
			this.ff13.visible = false;
			
		}
		
		this.m14.addEventListener("click", fl_MouseClickHandler_41.bind(this));
		
		function fl_MouseClickHandler_41()
		{
			this.mh14.visible = true;
			this.bh14.visible = false;
			this.fh14.visible = false;
			this.mm14.visible = true;
			this.bb14.visible = false;
			this.ff14.visible = false;
		}
		
		this.f14.addEventListener("click", fl_MouseClickHandler_42.bind(this));
		
		function fl_MouseClickHandler_42()
		{
			this.fh14.visible = true;
			this.mh14.visible = false;
			this.bh14.visible = false;
			this.ff14.visible = true;
			this.mm14.visible = false;
			this.bb14.visible = false;
		}
		
		this.b14.addEventListener("click", fl_MouseClickHandler_43.bind(this));
		
		function fl_MouseClickHandler_43()
		{
			this.bh14.visible = true;
			this.mh14.visible = false;
			this.fh14.visible = false;
			this.bb14.visible = true;
			this.mm14.visible = false;
			this.ff14.visible = false;
			
		}
		
		this.m15.addEventListener("click", fl_MouseClickHandler_44.bind(this));
		
		function fl_MouseClickHandler_44()
		{
			this.mh15.visible = true;
			this.bh15.visible = false;
			this.fh15.visible = false;
			this.mm15.visible = true;
			this.bb15.visible = false;
			this.ff15.visible = false;
		}
		
		this.f15.addEventListener("click", fl_MouseClickHandler_45.bind(this));
		
		function fl_MouseClickHandler_45()
		{
			this.fh15.visible = true;
			this.mh15.visible = false;
			this.bh15.visible = false;
			this.ff15.visible = true;
			this.mm15.visible = false;
			this.bb15.visible = false;
		}
		
		this.b15.addEventListener("click", fl_MouseClickHandler_46.bind(this));
		
		function fl_MouseClickHandler_46()
		{
			this.bh15.visible = true;
			this.mh15.visible = false;
			this.fh15.visible = false;
			this.bb15.visible = true;
			this.mm15.visible = false;
			this.ff15.visible = false;
		}
		
		this.m16.addEventListener("click", fl_MouseClickHandler_47.bind(this));
		
		function fl_MouseClickHandler_47()
		{
			this.mh16.visible = true;
			this.bh15.visible = false;
			this.fh16.visible = false;
			this.mm16.visible = true;
			this.bb15.visible = false;
			this.ff16.visible = false;
		}
		
		this.f16.addEventListener("click", fl_MouseClickHandler_48.bind(this));
		
		function fl_MouseClickHandler_48()
		{
			this.fh16.visible = true;
			this.mh16.visible = false;
			this.bh16.visible = false;
			this.ff16.visible = true;
			this.mm16.visible = false;
			this.bb16.visible = false;
		}
		
		this.b16.addEventListener("click", fl_MouseClickHandler_49.bind(this));
		
		function fl_MouseClickHandler_49()
		{
			this.bh16.visible = true;
			this.mh16.visible = false;
			this.fh16.visible = false;
			this.bb16.visible = true;
			this.mm16.visible = false;
			this.ff16.visible = false;
		}
		
		this.m17.addEventListener("click", fl_MouseClickHandler_50.bind(this));
		
		function fl_MouseClickHandler_50()
		{
			this.mh17.visible = true;
			this.bh17.visible = false;
			this.fh17.visible = false;
			this.mm17.visible = true;
			this.bb17.visible = false;
			this.ff17.visible = false;
		}
		
		this.f17.addEventListener("click", fl_MouseClickHandler_51.bind(this));
		
		function fl_MouseClickHandler_51()
		{
			this.fh17.visible = true;
			this.mh17.visible = false;
			this.bh17.visible = false;
			this.ff17.visible = true;
			this.mm17.visible = false;
			this.bb17.visible = false;
		}
		
		this.b17.addEventListener("click", fl_MouseClickHandler_52.bind(this));
		
		function fl_MouseClickHandler_52()
		{
			this.bh17.visible = true;
			this.mh17.visible = false;
			this.fh17.visible = false;
			this.bb17.visible = true;
			this.mm17.visible = false;
			this.ff17.visible = false;
			
		}
		
		this.m18.addEventListener("click", fl_MouseClickHandler_53.bind(this));
		
		function fl_MouseClickHandler_53()
		{
			this.mh18.visible = true;
			this.bh18.visible = false;
			this.fh18.visible = false;
			this.mm18.visible = true;
			this.bb18.visible = false;
			this.ff18.visible = false;
		}
		
		this.f18.addEventListener("click", fl_MouseClickHandler_54.bind(this));
		
		function fl_MouseClickHandler_54()
		{
			this.fh18.visible = true;
			this.mh18.visible = false;
			this.bh18.visible = false;
			this.ff18.visible = true;
			this.mm18.visible = false;
			this.bb18.visible = false;
		}
		
		this.b18.addEventListener("click", fl_MouseClickHandler_55.bind(this));
		
		function fl_MouseClickHandler_55()
		{
			this.bh18.visible = true;
			this.mh18.visible = false;
			this.fh18.visible = false;
			this.bb18.visible = true;
			this.mm18.visible = false;
			this.ff18.visible = false;
			
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Actions
	this.no18 = new lib.no();
	this.no18.name = "no18";
	this.no18.setTransform(1150.3,676.55,0.8108,0.8093,0,0,0,14,11.9);

	this.yes18 = new lib.yes();
	this.yes18.name = "yes18";
	this.yes18.setTransform(1154.2,677.75,0.5842,0.5759,0,0,0,26.1,15.7);

	this.no17 = new lib.no();
	this.no17.name = "no17";
	this.no17.setTransform(1150.3,639.55,0.8108,0.8093,0,0,0,14,11.9);

	this.yes17 = new lib.yes();
	this.yes17.name = "yes17";
	this.yes17.setTransform(1154.2,640.75,0.5842,0.5759,0,0,0,26.1,15.7);

	this.no16 = new lib.no();
	this.no16.name = "no16";
	this.no16.setTransform(1150.3,604.55,0.8108,0.8093,0,0,0,14,11.9);

	this.yes16 = new lib.yes();
	this.yes16.name = "yes16";
	this.yes16.setTransform(1154.2,605.75,0.5842,0.5759,0,0,0,26.1,15.7);

	this.no15 = new lib.no();
	this.no15.name = "no15";
	this.no15.setTransform(1150.3,563.25,0.8108,0.8093,0,0,0,14,11.9);

	this.yes15 = new lib.yes();
	this.yes15.name = "yes15";
	this.yes15.setTransform(1154.2,564.45,0.5842,0.5759,0,0,0,26.1,15.7);

	this.no14 = new lib.no();
	this.no14.name = "no14";
	this.no14.setTransform(1150.3,530.5,0.8108,0.8108,0,0,0,14,11.8);

	this.yes14 = new lib.yes();
	this.yes14.name = "yes14";
	this.yes14.setTransform(1154.2,531.75,0.5842,0.577,0,0,0,26.1,15.5);

	this.no13 = new lib.no();
	this.no13.name = "no13";
	this.no13.setTransform(1150.3,495.7,0.8108,0.8108,0,0,0,14,11.8);

	this.yes13 = new lib.yes();
	this.yes13.name = "yes13";
	this.yes13.setTransform(1154.2,497,0.5842,0.577,0,0,0,26.1,15.7);

	this.no12 = new lib.no();
	this.no12.name = "no12";
	this.no12.setTransform(1150.3,456.55,0.8108,0.8108,0,0,0,14,11.9);

	this.yes12 = new lib.yes();
	this.yes12.name = "yes12";
	this.yes12.setTransform(1154.2,457.8,0.5842,0.577,0,0,0,26.1,15.7);

	this.no11 = new lib.no();
	this.no11.name = "no11";
	this.no11.setTransform(1150.3,421.2,0.8108,0.8108,0,0,0,14,11.9);

	this.yes11 = new lib.yes();
	this.yes11.name = "yes11";
	this.yes11.setTransform(1154.2,422.4,0.5842,0.577,0,0,0,26.1,15.7);

	this.no10 = new lib.no();
	this.no10.name = "no10";
	this.no10.setTransform(1150.3,385.8,0.8108,0.8108,0,0,0,14,11.9);

	this.yes10 = new lib.yes();
	this.yes10.name = "yes10";
	this.yes10.setTransform(1154.2,387,0.5842,0.577,0,0,0,26.1,15.6);

	this.no9 = new lib.no();
	this.no9.name = "no9";
	this.no9.setTransform(1150.3,347.8,0.8108,0.8108,0,0,0,14,11.9);

	this.yes9 = new lib.yes();
	this.yes9.name = "yes9";
	this.yes9.setTransform(1154.2,349.05,0.5842,0.577,0,0,0,26.1,15.7);

	this.no8 = new lib.no();
	this.no8.name = "no8";
	this.no8.setTransform(1150.3,311.9,0.8108,0.8108,0,0,0,14,11.9);

	this.yes8 = new lib.yes();
	this.yes8.name = "yes8";
	this.yes8.setTransform(1154.2,313.1,0.5842,0.577,0,0,0,26.1,15.6);

	this.no7 = new lib.no();
	this.no7.name = "no7";
	this.no7.setTransform(1150.3,278.25,0.8108,0.8108,0,0,0,14,11.9);

	this.yes7 = new lib.yes();
	this.yes7.name = "yes7";
	this.yes7.setTransform(1154.2,279.45,0.5842,0.577,0,0,0,26.1,15.6);

	this.no5 = new lib.no();
	this.no5.name = "no5";
	this.no5.setTransform(1150.3,205.55,0.8108,0.8108,0,0,0,14,11.8);

	this.yes5 = new lib.yes();
	this.yes5.name = "yes5";
	this.yes5.setTransform(1154.2,206.8,0.5842,0.577,0,0,0,26.1,15.5);

	this.no6 = new lib.no();
	this.no6.name = "no6";
	this.no6.setTransform(1150.3,239.95,0.8108,0.8108,0,0,0,14,11.8);

	this.yes6 = new lib.yes();
	this.yes6.name = "yes6";
	this.yes6.setTransform(1154.2,241.2,0.5842,0.577,0,0,0,26.1,15.6);

	this.no4 = new lib.no();
	this.no4.name = "no4";
	this.no4.setTransform(1150.3,165.15,0.8108,0.8108,0,0,0,14,11.8);

	this.yes4 = new lib.yes();
	this.yes4.name = "yes4";
	this.yes4.setTransform(1154.2,166.4,0.5842,0.577,0,0,0,26.1,15.6);

	this.no3 = new lib.no();
	this.no3.name = "no3";
	this.no3.setTransform(1150.3,127.2,0.8108,0.8108,0,0,0,14,11.8);

	this.yes3 = new lib.yes();
	this.yes3.name = "yes3";
	this.yes3.setTransform(1154.2,128.5,0.5842,0.577,0,0,0,26.1,15.6);

	this.no2 = new lib.no();
	this.no2.name = "no2";
	this.no2.setTransform(1150.3,93.5,0.8108,0.8108,0,0,0,14,11.8);

	this.yes2 = new lib.yes();
	this.yes2.name = "yes2";
	this.yes2.setTransform(1154.2,94.75,0.5842,0.577,0,0,0,26.1,15.6);

	this.no1 = new lib.no();
	this.no1.name = "no1";
	this.no1.setTransform(1150.3,51.9,0.8108,0.8108,0,0,0,14,11.8);

	this.yes1 = new lib.yes();
	this.yes1.name = "yes1";
	this.yes1.setTransform(1154.2,53.15,0.5842,0.577,0,0,0,26.1,15.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.yes1},{t:this.no1},{t:this.yes2},{t:this.no2},{t:this.yes3},{t:this.no3},{t:this.yes4},{t:this.no4},{t:this.yes6},{t:this.no6},{t:this.yes5},{t:this.no5},{t:this.yes7},{t:this.no7},{t:this.yes8},{t:this.no8},{t:this.yes9},{t:this.no9},{t:this.yes10},{t:this.no10},{t:this.yes11},{t:this.no11},{t:this.yes12},{t:this.no12},{t:this.yes13},{t:this.no13},{t:this.yes14},{t:this.no14},{t:this.yes15},{t:this.no15},{t:this.yes16},{t:this.no16},{t:this.yes17},{t:this.no17},{t:this.yes18},{t:this.no18}]},1).wait(1));

	// interface_buttons
	this.solve1_mc = new lib.solvebutton();
	this.solve1_mc.name = "solve1_mc";
	this.solve1_mc.setTransform(1082.35,738.3,1.487,1.487);
	new cjs.ButtonHelper(this.solve1_mc, 0, 1, 2);

	this.help_mc = new lib.helpbutton();
	this.help_mc.name = "help_mc";
	this.help_mc.setTransform(867.15,737.3,1.487,1.487,0,0,0,0,0.1);
	new cjs.ButtonHelper(this.help_mc, 0, 1, 2);

	this.reset_mc = new lib.resetbutton();
	this.reset_mc.name = "reset_mc";
	this.reset_mc.setTransform(1201.35,738.3,1.487,1.487);
	new cjs.ButtonHelper(this.reset_mc, 0, 1, 2);

	this.check1_mc = new lib.checkbutton();
	this.check1_mc.name = "check1_mc";
	this.check1_mc.setTransform(963.25,738.2,1.4877,1.487);
	new cjs.ButtonHelper(this.check1_mc, 0, 1, 2);

	this.solve_mc = new lib.solvebutton();
	this.solve_mc.name = "solve_mc";
	this.solve_mc.setTransform(1082.35,738.3,1.487,1.487);
	new cjs.ButtonHelper(this.solve_mc, 0, 1, 2);

	this.check_mc = new lib.checkbutton();
	this.check_mc.name = "check_mc";
	this.check_mc.setTransform(963.35,738.3,1.487,1.487);
	new cjs.ButtonHelper(this.check_mc, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.check1_mc,p:{regX:0,regY:0,scaleX:1.4877,scaleY:1.487,x:963.25,y:738.2}},{t:this.reset_mc},{t:this.help_mc},{t:this.solve1_mc,p:{regX:0,regY:0,scaleX:1.487,scaleY:1.487,x:1082.35,y:738.3}}]}).to({state:[{t:this.solve1_mc,p:{regX:0.1,regY:-1,scaleX:1.4175,scaleY:1.4357,x:1082.45,y:736.85}},{t:this.check1_mc,p:{regX:0.1,regY:0.1,scaleX:1.4175,scaleY:1.4357,x:963.3,y:738.45}},{t:this.check_mc},{t:this.solve_mc},{t:this.reset_mc},{t:this.help_mc}]},1).wait(1));

	// border
	this.start_mc = new lib.startbutton();
	this.start_mc.name = "start_mc";
	this.start_mc.setTransform(633.75,524.95,1.487,1.487);
	new cjs.ButtonHelper(this.start_mc, 0, 1, 2);

	this.instance = new lib.border("synched",0);
	this.instance.setTransform(632.7,386.65,1.7386,1.7386);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.start_mc}]}).to({state:[{t:this.instance}]},1).wait(1));

	// Text
	this.instance_1 = new lib.CachedBmp_1();
	this.instance_1.setTransform(10.8,262.75,0.5,0.5);

	this.mm18 = new lib.mm1();
	this.mm18.name = "mm18";
	this.mm18.setTransform(915.9,675.15,1,1,0,0,0,15,15);

	this.mm17 = new lib.mm1();
	this.mm17.name = "mm17";
	this.mm17.setTransform(915.9,638.7,1,1,0,0,0,15,15);

	this.mm16 = new lib.mm1();
	this.mm16.name = "mm16";
	this.mm16.setTransform(915.9,603.8,1,1,0,0,0,15,15);

	this.mm15 = new lib.mm1();
	this.mm15.name = "mm15";
	this.mm15.setTransform(915.9,565.9,1,1,0,0,0,15,15);

	this.mm14 = new lib.mm1();
	this.mm14.name = "mm14";
	this.mm14.setTransform(915.9,530.95,1,1,0,0,0,15,15);

	this.mm13 = new lib.mm1();
	this.mm13.name = "mm13";
	this.mm13.setTransform(915.9,495.3,1,1,0,0,0,15,15);

	this.mm12 = new lib.mm1();
	this.mm12.name = "mm12";
	this.mm12.setTransform(915.9,457.85,1,1,0,0,0,15,15);

	this.mm11 = new lib.mm1();
	this.mm11.name = "mm11";
	this.mm11.setTransform(915.9,421.4,1,1,0,0,0,15,15);

	this.mm10 = new lib.mm1();
	this.mm10.name = "mm10";
	this.mm10.setTransform(915.9,386.5,1,1,0,0,0,15,15);

	this.mm9 = new lib.mm1();
	this.mm9.name = "mm9";
	this.mm9.setTransform(915.9,348.6,1,1,0,0,0,15,15);

	this.mm8 = new lib.mm1();
	this.mm8.name = "mm8";
	this.mm8.setTransform(915.9,312.9,1,1,0,0,0,15,15);

	this.mm7 = new lib.mm1();
	this.mm7.name = "mm7";
	this.mm7.setTransform(915.9,278,1,1,0,0,0,15,15);

	this.mm6 = new lib.mm1();
	this.mm6.name = "mm6";
	this.mm6.setTransform(915.9,240.2,1,1,0,0,0,15,15);

	this.mm5 = new lib.mm1();
	this.mm5.name = "mm5";
	this.mm5.setTransform(915.9,205.25,1,1,0,0,0,15,15);

	this.mm4 = new lib.mm1();
	this.mm4.name = "mm4";
	this.mm4.setTransform(915.9,166.35,1,1,0,0,0,15,15);

	this.mm3 = new lib.mm1();
	this.mm3.name = "mm3";
	this.mm3.setTransform(915.9,128.45,1,1,0,0,0,15,15);

	this.mm2 = new lib.mm1();
	this.mm2.name = "mm2";
	this.mm2.setTransform(915.9,92,1,1,0,0,0,15,15);

	this.mm1 = new lib.mm1();
	this.mm1.name = "mm1";
	this.mm1.setTransform(915.9,53.1,1,1,0,0,0,15,15);

	this.ff1 = new lib.ff1();
	this.ff1.name = "ff1";
	this.ff1.setTransform(1010.4,53.1,1,1,0,0,0,15,15);

	this.ff18 = new lib.ff1();
	this.ff18.name = "ff18";
	this.ff18.setTransform(1010.4,675.15,1,1,0,0,0,15,15);

	this.ff17 = new lib.ff1();
	this.ff17.name = "ff17";
	this.ff17.setTransform(1010.4,639.45,1,1,0,0,0,15,15);

	this.ff16 = new lib.ff1();
	this.ff16.name = "ff16";
	this.ff16.setTransform(1010.4,604.55,1,1,0,0,0,15,15);

	this.ff15 = new lib.ff1();
	this.ff15.name = "ff15";
	this.ff15.setTransform(1010.4,565.9,1,1,0,0,0,15,15);

	this.ff14 = new lib.ff1();
	this.ff14.name = "ff14";
	this.ff14.setTransform(1010.4,530.95,1,1,0,0,0,15,15);

	this.ff13 = new lib.ff1();
	this.ff13.name = "ff13";
	this.ff13.setTransform(1010.4,495.3,1,1,0,0,0,15,15);

	this.ff12 = new lib.ff1();
	this.ff12.name = "ff12";
	this.ff12.setTransform(1010.4,457.1,1,1,0,0,0,15,15);

	this.ff11 = new lib.ff1();
	this.ff11.name = "ff11";
	this.ff11.setTransform(1010.4,421.4,1,1,0,0,0,15,15);

	this.ff10 = new lib.ff1();
	this.ff10.name = "ff10";
	this.ff10.setTransform(1010.4,387.25,1,1,0,0,0,15,15);

	this.ff9 = new lib.ff1();
	this.ff9.name = "ff9";
	this.ff9.setTransform(1010.4,349.35,1,1,0,0,0,15,15);

	this.ff8 = new lib.ff1();
	this.ff8.name = "ff8";
	this.ff8.setTransform(1010.4,313.65,1,1,0,0,0,15,15);

	this.ff7 = new lib.ff1();
	this.ff7.name = "ff7";
	this.ff7.setTransform(1010.4,278.75,1,1,0,0,0,15,15);

	this.ff6 = new lib.ff1();
	this.ff6.name = "ff6";
	this.ff6.setTransform(1010.4,240.95,1,1,0,0,0,15,15);

	this.ff5 = new lib.ff1();
	this.ff5.name = "ff5";
	this.ff5.setTransform(1010.4,205.25,1,1,0,0,0,15,15);

	this.ff4 = new lib.ff1();
	this.ff4.name = "ff4";
	this.ff4.setTransform(1010.4,166.35,1,1,0,0,0,15,15);

	this.ff3 = new lib.ff1();
	this.ff3.name = "ff3";
	this.ff3.setTransform(1010.4,127.7,1,1,0,0,0,15,15);

	this.ff2 = new lib.ff1();
	this.ff2.name = "ff2";
	this.ff2.setTransform(1010.4,92,1,1,0,0,0,15,15);

	this.bb18 = new lib.bb1();
	this.bb18.name = "bb18";
	this.bb18.setTransform(1102.45,675.15,1,1,0,0,0,15,15);

	this.bb17 = new lib.bb1();
	this.bb17.name = "bb17";
	this.bb17.setTransform(1102.45,638.7,1,1,0,0,0,15,15);

	this.bb16 = new lib.bb1();
	this.bb16.name = "bb16";
	this.bb16.setTransform(1102.45,605.7,1,1,0,0,0,15,15);

	this.bb15 = new lib.bb1();
	this.bb15.name = "bb15";
	this.bb15.setTransform(1102.45,565.9,1,1,0,0,0,15,15);

	this.bb14 = new lib.bb1();
	this.bb14.name = "bb14";
	this.bb14.setTransform(1102.45,530.2,1,1,0,0,0,15,15);

	this.bb13 = new lib.bb1();
	this.bb13.name = "bb13";
	this.bb13.setTransform(1102.45,495.3,1,1,0,0,0,15,15);

	this.bb12 = new lib.bb1();
	this.bb12.name = "bb12";
	this.bb12.setTransform(1102.45,457.1,1,1,0,0,0,15,15);

	this.bb11 = new lib.bb1();
	this.bb11.name = "bb11";
	this.bb11.setTransform(1102.45,421.4,1,1,0,0,0,15,15);

	this.bb10 = new lib.bb1();
	this.bb10.name = "bb10";
	this.bb10.setTransform(1102.45,387.25,1,1,0,0,0,15,15);

	this.bb9 = new lib.bb1();
	this.bb9.name = "bb9";
	this.bb9.setTransform(1102.45,349.35,1,1,0,0,0,15,15);

	this.bb8 = new lib.bb1();
	this.bb8.name = "bb8";
	this.bb8.setTransform(1102.45,312.7,1,1,0,0,0,15,15);

	this.bb7 = new lib.bb1();
	this.bb7.name = "bb7";
	this.bb7.setTransform(1102.45,278,1,1,0,0,0,15,15);

	this.bb5 = new lib.bb1();
	this.bb5.name = "bb5";
	this.bb5.setTransform(1102.45,204.5,1,1,0,0,0,15,15);

	this.bb6 = new lib.bb1();
	this.bb6.name = "bb6";
	this.bb6.setTransform(1102.45,240.2,1,1,0,0,0,15,15);

	this.bb4 = new lib.bb1();
	this.bb4.name = "bb4";
	this.bb4.setTransform(1102.45,165.6,1,1,0,0,0,15,15);

	this.bb3 = new lib.bb1();
	this.bb3.name = "bb3";
	this.bb3.setTransform(1102.45,127.7,1,1,0,0,0,15,15);

	this.bb2 = new lib.bb1();
	this.bb2.name = "bb2";
	this.bb2.setTransform(1102.45,92,1,1,0,0,0,15,15);

	this.bb1 = new lib.bb1();
	this.bb1.name = "bb1";
	this.bb1.setTransform(1102.45,53.1,1,1,0,0,0,15,15);

	this.b18 = new lib.b();
	this.b18.name = "b18";
	this.b18.setTransform(1102.45,674.4,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.b18, 0, 1, 2, false, new lib.b(), 3);

	this.f18 = new lib.f();
	this.f18.name = "f18";
	this.f18.setTransform(1010.4,674.4,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.f18, 0, 1, 2, false, new lib.f(), 3);

	this.m18 = new lib.m();
	this.m18.name = "m18";
	this.m18.setTransform(915.9,674.7,1,1,0,0,0,15,15.3);
	new cjs.ButtonHelper(this.m18, 0, 1, 2, false, new lib.m(), 3);

	this.b17 = new lib.b();
	this.b17.name = "b17";
	this.b17.setTransform(1102.45,638.7,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.b17, 0, 1, 2, false, new lib.b(), 3);

	this.f17 = new lib.f();
	this.f17.name = "f17";
	this.f17.setTransform(1010.4,638.7,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.f17, 0, 1, 2, false, new lib.f(), 3);

	this.m17 = new lib.m();
	this.m17.name = "m17";
	this.m17.setTransform(915.9,639,1,1,0,0,0,15,15.3);
	new cjs.ButtonHelper(this.m17, 0, 1, 2, false, new lib.m(), 3);

	this.b16 = new lib.b();
	this.b16.name = "b16";
	this.b16.setTransform(1102.45,603.8,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.b16, 0, 1, 2, false, new lib.b(), 3);

	this.f16 = new lib.f();
	this.f16.name = "f16";
	this.f16.setTransform(1010.4,603.8,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.f16, 0, 1, 2, false, new lib.f(), 3);

	this.m16 = new lib.m();
	this.m16.name = "m16";
	this.m16.setTransform(915.9,604.1,1,1,0,0,0,15,15.3);
	new cjs.ButtonHelper(this.m16, 0, 1, 2, false, new lib.m(), 3);

	this.b15 = new lib.b();
	this.b15.name = "b15";
	this.b15.setTransform(1102.45,565.9,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.b15, 0, 1, 2, false, new lib.b(), 3);

	this.f15 = new lib.f();
	this.f15.name = "f15";
	this.f15.setTransform(1010.4,565.9,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.f15, 0, 1, 2, false, new lib.f(), 3);

	this.m15 = new lib.m();
	this.m15.name = "m15";
	this.m15.setTransform(915.9,566.2,1,1,0,0,0,15,15.3);
	new cjs.ButtonHelper(this.m15, 0, 1, 2, false, new lib.m(), 3);

	this.b14 = new lib.b();
	this.b14.name = "b14";
	this.b14.setTransform(1102.45,530.2,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.b14, 0, 1, 2, false, new lib.b(), 3);

	this.f14 = new lib.f();
	this.f14.name = "f14";
	this.f14.setTransform(1010.4,530.2,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.f14, 0, 1, 2, false, new lib.f(), 3);

	this.m14 = new lib.m();
	this.m14.name = "m14";
	this.m14.setTransform(915.9,530.5,1,1,0,0,0,15,15.3);
	new cjs.ButtonHelper(this.m14, 0, 1, 2, false, new lib.m(), 3);

	this.b13 = new lib.b();
	this.b13.name = "b13";
	this.b13.setTransform(1102.45,495.3,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.b13, 0, 1, 2, false, new lib.b(), 3);

	this.f13 = new lib.f();
	this.f13.name = "f13";
	this.f13.setTransform(1010.4,495.3,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.f13, 0, 1, 2, false, new lib.f(), 3);

	this.m13 = new lib.m();
	this.m13.name = "m13";
	this.m13.setTransform(915.9,495.6,1,1,0,0,0,15,15.3);
	new cjs.ButtonHelper(this.m13, 0, 1, 2, false, new lib.m(), 3);

	this.b12 = new lib.b();
	this.b12.name = "b12";
	this.b12.setTransform(1102.45,457.1,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.b12, 0, 1, 2, false, new lib.b(), 3);

	this.f12 = new lib.f();
	this.f12.name = "f12";
	this.f12.setTransform(1010.4,457.1,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.f12, 0, 1, 2, false, new lib.f(), 3);

	this.m12 = new lib.m();
	this.m12.name = "m12";
	this.m12.setTransform(915.9,457.4,1,1,0,0,0,15,15.3);
	new cjs.ButtonHelper(this.m12, 0, 1, 2, false, new lib.m(), 3);

	this.b11 = new lib.b();
	this.b11.name = "b11";
	this.b11.setTransform(1102.45,421.4,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.b11, 0, 1, 2, false, new lib.b(), 3);

	this.f11 = new lib.f();
	this.f11.name = "f11";
	this.f11.setTransform(1010.4,421.4,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.f11, 0, 1, 2, false, new lib.f(), 3);

	this.m11 = new lib.m();
	this.m11.name = "m11";
	this.m11.setTransform(915.9,421.7,1,1,0,0,0,15,15.3);
	new cjs.ButtonHelper(this.m11, 0, 1, 2, false, new lib.m(), 3);

	this.b10 = new lib.b();
	this.b10.name = "b10";
	this.b10.setTransform(1102.45,386.5,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.b10, 0, 1, 2, false, new lib.b(), 3);

	this.f10 = new lib.f();
	this.f10.name = "f10";
	this.f10.setTransform(1010.4,386.5,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.f10, 0, 1, 2, false, new lib.f(), 3);

	this.m10 = new lib.m();
	this.m10.name = "m10";
	this.m10.setTransform(915.9,386.8,1,1,0,0,0,15,15.3);
	new cjs.ButtonHelper(this.m10, 0, 1, 2, false, new lib.m(), 3);

	this.b9 = new lib.b();
	this.b9.name = "b9";
	this.b9.setTransform(1102.45,348.6,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.b9, 0, 1, 2, false, new lib.b(), 3);

	this.f9 = new lib.f();
	this.f9.name = "f9";
	this.f9.setTransform(1010.4,348.6,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.f9, 0, 1, 2, false, new lib.f(), 3);

	this.m9 = new lib.m();
	this.m9.name = "m9";
	this.m9.setTransform(915.9,348.9,1,1,0,0,0,15,15.3);
	new cjs.ButtonHelper(this.m9, 0, 1, 2, false, new lib.m(), 3);

	this.b8 = new lib.b();
	this.b8.name = "b8";
	this.b8.setTransform(1102.45,312.9,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.b8, 0, 1, 2, false, new lib.b(), 3);

	this.f8 = new lib.f();
	this.f8.name = "f8";
	this.f8.setTransform(1010.4,312.9,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.f8, 0, 1, 2, false, new lib.f(), 3);

	this.m8 = new lib.m();
	this.m8.name = "m8";
	this.m8.setTransform(915.9,313.2,1,1,0,0,0,15,15.3);
	new cjs.ButtonHelper(this.m8, 0, 1, 2, false, new lib.m(), 3);

	this.b7 = new lib.b();
	this.b7.name = "b7";
	this.b7.setTransform(1102.45,278,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.b7, 0, 1, 2, false, new lib.b(), 3);

	this.f7 = new lib.f();
	this.f7.name = "f7";
	this.f7.setTransform(1010.4,278,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.f7, 0, 1, 2, false, new lib.f(), 3);

	this.m7 = new lib.m();
	this.m7.name = "m7";
	this.m7.setTransform(915.9,278.3,1,1,0,0,0,15,15.3);
	new cjs.ButtonHelper(this.m7, 0, 1, 2, false, new lib.m(), 3);

	this.b6 = new lib.b();
	this.b6.name = "b6";
	this.b6.setTransform(1102.45,240.2,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.b6, 0, 1, 2, false, new lib.b(), 3);

	this.f6 = new lib.f();
	this.f6.name = "f6";
	this.f6.setTransform(1010.4,240.2,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.f6, 0, 1, 2, false, new lib.f(), 3);

	this.m6 = new lib.m();
	this.m6.name = "m6";
	this.m6.setTransform(915.9,240.5,1,1,0,0,0,15,15.3);
	new cjs.ButtonHelper(this.m6, 0, 1, 2, false, new lib.m(), 3);

	this.b5 = new lib.b();
	this.b5.name = "b5";
	this.b5.setTransform(1102.45,204.5,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.b5, 0, 1, 2, false, new lib.b(), 3);

	this.f5 = new lib.f();
	this.f5.name = "f5";
	this.f5.setTransform(1010.4,204.5,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.f5, 0, 1, 2, false, new lib.f(), 3);

	this.m5 = new lib.m();
	this.m5.name = "m5";
	this.m5.setTransform(915.9,204.8,1,1,0,0,0,15,15.3);
	new cjs.ButtonHelper(this.m5, 0, 1, 2, false, new lib.m(), 3);

	this.b4 = new lib.b();
	this.b4.name = "b4";
	this.b4.setTransform(1102.45,165.6,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.b4, 0, 1, 2, false, new lib.b(), 3);

	this.f4 = new lib.f();
	this.f4.name = "f4";
	this.f4.setTransform(1010.4,165.6,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.f4, 0, 1, 2, false, new lib.f(), 3);

	this.m4 = new lib.m();
	this.m4.name = "m4";
	this.m4.setTransform(915.9,165.9,1,1,0,0,0,15,15.3);
	new cjs.ButtonHelper(this.m4, 0, 1, 2, false, new lib.m(), 3);

	this.b3 = new lib.b();
	this.b3.name = "b3";
	this.b3.setTransform(1102.45,127.7,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.b3, 0, 1, 2, false, new lib.b(), 3);

	this.f3 = new lib.f();
	this.f3.name = "f3";
	this.f3.setTransform(1010.4,127.7,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.f3, 0, 1, 2, false, new lib.f(), 3);

	this.m3 = new lib.m();
	this.m3.name = "m3";
	this.m3.setTransform(915.9,128,1,1,0,0,0,15,15.3);
	new cjs.ButtonHelper(this.m3, 0, 1, 2, false, new lib.m(), 3);

	this.b2 = new lib.b();
	this.b2.name = "b2";
	this.b2.setTransform(1102.45,92,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.b2, 0, 1, 2, false, new lib.b(), 3);

	this.f2 = new lib.f();
	this.f2.name = "f2";
	this.f2.setTransform(1010.4,92,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.f2, 0, 1, 2, false, new lib.f(), 3);

	this.m2 = new lib.m();
	this.m2.name = "m2";
	this.m2.setTransform(915.9,92.3,1,1,0,0,0,15,15.3);
	new cjs.ButtonHelper(this.m2, 0, 1, 2, false, new lib.m(), 3);

	this.b1 = new lib.b();
	this.b1.name = "b1";
	this.b1.setTransform(1102.45,53.1,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.b1, 0, 1, 2, false, new lib.b(), 3);

	this.f1 = new lib.f();
	this.f1.name = "f1";
	this.f1.setTransform(1010.4,53.1,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.f1, 0, 1, 2, false, new lib.f(), 3);

	this.m1 = new lib.m();
	this.m1.name = "m1";
	this.m1.setTransform(915.9,53.4,1,1,0,0,0,15,15.3);
	new cjs.ButtonHelper(this.m1, 0, 1, 2, false, new lib.m(), 3);

	this.instance_2 = new lib.CachedBmp_2();
	this.instance_2.setTransform(133.4,38.1,0.5,0.5);

	this.mh18 = new lib.mh18();
	this.mh18.name = "mh18";
	this.mh18.setTransform(470.4,680,24.1071,1,0,0,0,14,16.5);

	this.fh18 = new lib.fh18();
	this.fh18.name = "fh18";
	this.fh18.setTransform(470.4,680,20.4545,1,0,0,0,16.5,16.5);

	this.mh17 = new lib.mh17();
	this.mh17.name = "mh17";
	this.mh17.setTransform(290.7,642.9,6.0567,0.9167,0,0,0,26,18);

	this.fh17 = new lib.fh17();
	this.fh17.name = "fh17";
	this.fh17.setTransform(290.65,642.9,8.7486,0.8462,0,0,0,18,19.5);

	this.mh16 = new lib.mh16();
	this.mh16.name = "mh16";
	this.mh16.setTransform(318.3,607.2,7.8723,0.9167,0,0,0,23.5,18);

	this.fh16 = new lib.fh16();
	this.fh16.name = "fh16";
	this.fh16.setTransform(318.25,607.2,9.25,1,0,0,0,20,16.5);

	this.mh15 = new lib.mh15();
	this.mh15.name = "mh15";
	this.mh15.setTransform(370.9,572.3,9.1346,1.0645,0,0,0,26,15.5);

	this.fh15 = new lib.fh15();
	this.fh15.name = "fh15";
	this.fh15.setTransform(370.9,572.4,9.1346,1.0645,0,0,0,26,15.6);

	this.mh14 = new lib.mh14();
	this.mh14.name = "mh14";
	this.mh14.setTransform(368.4,529.45,8.2456,1,0,0,0,28.5,16.5);

	this.fh14 = new lib.fh14();
	this.fh14.name = "fh14";
	this.fh14.setTransform(368.4,529.5,8.2456,0.6735,0,0,0,28.5,24.6);

	this.mh13 = new lib.mh13();
	this.mh13.name = "mh13";
	this.mh13.setTransform(461.5,493.8,14.6009,1,0,0,0,22.5,16.5);

	this.fh13 = new lib.fh13();
	this.fh13.name = "fh13";
	this.fh13.setTransform(461.65,493.8,14.2826,1,0,0,0,23,16.5);

	this.mh12 = new lib.mh12();
	this.mh12.name = "mh12";
	this.mh12.setTransform(270.55,456.4,6.25,1.0313,0,0,0,22,16.1);

	this.fh12 = new lib.fh12();
	this.fh12.name = "fh12";
	this.fh12.setTransform(270.55,456.35,6.5476,1,0,0,0,21,16.5);

	this.mh11 = new lib.mh11();
	this.mh11.name = "mh11";
	this.mh11.setTransform(325.55,420.65,11,1,0,0,0,17.5,16.5);

	this.fh11 = new lib.fh11();
	this.fh11.name = "fh11";
	this.fh11.setTransform(325.55,420.75,6.875,1.1,0,0,0,28,15.1);

	this.mh10 = new lib.mh10();
	this.mh10.name = "mh10";
	this.mh10.setTransform(273.35,385,1,1,0,0,0,140,16.5);

	this.fh10 = new lib.fh10();
	this.fh10.name = "fh10";
	this.fh10.setTransform(273.35,385,1,1,0,0,0,140,16.5);

	this.mh9 = new lib.mh9();
	this.mh9.name = "mh9";
	this.mh9.setTransform(168.95,350.1,5.3521,1,0,0,0,6.7,16.5);

	this.fh9 = new lib.fh9();
	this.fh9.name = "fh9";
	this.fh9.setTransform(323.1,350.1,4.086,1,0,0,0,46.5,16.5);

	this.mh8 = new lib.mh8();
	this.mh8.name = "mh8";
	this.mh8.setTransform(273.25,312.15,1,1,0,0,0,140,16.5);

	this.fh8 = new lib.fh8();
	this.fh8.name = "fh8";
	this.fh8.setTransform(273.25,312.15,1,1,0,0,0,140,16.5);

	this.mh7 = new lib.mh7();
	this.mh7.name = "mh7";
	this.mh7.setTransform(310.7,276.5,1,1,0,0,0,177.5,16.5);

	this.fh7 = new lib.fh7();
	this.fh7.name = "fh7";
	this.fh7.setTransform(310.7,276.5,1,1,0,0,0,177.5,16.5);

	this.mh6 = new lib.mh6();
	this.mh6.name = "mh6";
	this.mh6.setTransform(319.65,238.7,1,1,0,0,0,186.5,16.5);

	this.fh6 = new lib.fh6();
	this.fh6.name = "fh6";
	this.fh6.setTransform(319.65,238.7,1,1,0,0,0,186.5,16.5);

	this.mh5 = new lib.mh5();
	this.mh5.name = "mh5";
	this.mh5.setTransform(335.9,203,1,1,0,0,0,202.5,16.5);

	this.fh5 = new lib.fh5();
	this.fh5.name = "fh5";
	this.fh5.setTransform(335.9,203,1,1,0,0,0,202.5,16.5);

	this.mh4 = new lib.mh4();
	this.mh4.name = "mh4";
	this.mh4.setTransform(329.75,164.1,12.2813,1,0,0,0,16,16.5);

	this.fh4 = new lib.fh4();
	this.fh4.name = "fh4";
	this.fh4.setTransform(329.75,164.1,9.5854,1,0,0,0,20.5,16.5);

	this.mh3 = new lib.mh3();
	this.mh3.name = "mh3";
	this.mh3.setTransform(373.3,126.95,1,1,0,0,0,240,16.5);

	this.fh3 = new lib.fh3();
	this.fh3.name = "fh3";
	this.fh3.setTransform(373.3,126.95,1,1,0,0,0,240,16.5);

	this.mh2 = new lib.mh2();
	this.mh2.name = "mh2";
	this.mh2.setTransform(268.35,91.25,1,1,0,0,0,135,16.5);

	this.mh1 = new lib.mh();
	this.mh1.name = "mh1";
	this.mh1.setTransform(303.1,54.6,1,1,0,0,0,170,16.5);

	this.fh1 = new lib.fh();
	this.fh1.name = "fh1";
	this.fh1.setTransform(302.95,54.6,1,1,0,0,0,170,16.5);

	this.bh1 = new lib.bh();
	this.bh1.name = "bh1";
	this.bh1.setTransform(303.4,54.6,1,1,0,0,0,170,16.5);

	this.bh2 = new lib.bh();
	this.bh2.name = "bh2";
	this.bh2.setTransform(268.4,91.25,0.7941,1,0,0,0,170.1,16.5);

	this.bh3 = new lib.bh();
	this.bh3.name = "bh3";
	this.bh3.setTransform(373.45,126.95,1.4118,1,0,0,0,170.1,16.5);

	this.bh6 = new lib.bh();
	this.bh6.name = "bh6";
	this.bh6.setTransform(319.85,238.7,1.097,1,0,0,0,170.2,16.5);

	this.bh5 = new lib.bh();
	this.bh5.name = "bh5";
	this.bh5.setTransform(336,203,1.1911,1,0,0,0,170.1,16.5);

	this.bh4 = new lib.bh();
	this.bh4.name = "bh4";
	this.bh4.setTransform(329.85,164.1,1.1558,1,0,0,0,170.1,16.5);

	this.bh11 = new lib.bh();
	this.bh11.name = "bh11";
	this.bh11.setTransform(325.75,420.65,1.1323,1,0,0,0,170.2,16.5);

	this.bh10 = new lib.bh();
	this.bh10.name = "bh10";
	this.bh10.setTransform(273.5,385,0.8235,1,0,0,0,170.2,16.5);

	this.bh9 = new lib.bh();
	this.bh9.name = "bh9";
	this.bh9.setTransform(323.2,350.1,1.1176,1,0,0,0,170.1,16.5);

	this.bh8 = new lib.bh();
	this.bh8.name = "bh8";
	this.bh8.setTransform(273.4,312.15,0.8235,1,0,0,0,170.2,16.5);

	this.bh7 = new lib.bh();
	this.bh7.name = "bh7";
	this.bh7.setTransform(310.9,276.5,1.0441,1,0,0,0,170.2,16.5);

	this.bh12 = new lib.bh();
	this.bh12.name = "bh12";
	this.bh12.setTransform(270.7,456.35,0.8088,1,0,0,0,170.2,16.5);

	this.bh13 = new lib.bh();
	this.bh13.name = "bh13";
	this.bh13.setTransform(462.1,493.8,1.9324,1,0,0,0,170.2,16.5);

	this.bh18 = new lib.bh();
	this.bh18.name = "bh18";
	this.bh18.setTransform(470.85,680,1.9853,1,0,0,0,170.2,16.5);

	this.bh17 = new lib.bh();
	this.bh17.name = "bh17";
	this.bh17.setTransform(290.95,642.9,0.9264,1,0,0,0,170.3,16.5);

	this.bh16 = new lib.bh();
	this.bh16.name = "bh16";
	this.bh16.setTransform(318.6,607.2,1.0882,1,0,0,0,170.3,16.5);

	this.bh15 = new lib.bh();
	this.bh15.name = "bh15";
	this.bh15.setTransform(371.15,572.3,1.397,1,0,0,0,170.2,16.5);

	this.bh14 = new lib.bh();
	this.bh14.name = "bh14";
	this.bh14.setTransform(368.65,529.45,1.3823,1,0,0,0,170.2,16.5);

	this.fh2 = new lib.fh2();
	this.fh2.name = "fh2";
	this.fh2.setTransform(268.35,91.25,1,1,0,0,0,135,16.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.fh2},{t:this.bh14},{t:this.bh15},{t:this.bh16},{t:this.bh17},{t:this.bh18},{t:this.bh13},{t:this.bh12},{t:this.bh7},{t:this.bh8},{t:this.bh9},{t:this.bh10},{t:this.bh11},{t:this.bh4},{t:this.bh5},{t:this.bh6},{t:this.bh3},{t:this.bh2},{t:this.bh1},{t:this.fh1},{t:this.mh1},{t:this.mh2},{t:this.fh3},{t:this.mh3},{t:this.fh4},{t:this.mh4},{t:this.fh5},{t:this.mh5},{t:this.fh6},{t:this.mh6},{t:this.fh7},{t:this.mh7},{t:this.fh8},{t:this.mh8},{t:this.fh9},{t:this.mh9},{t:this.fh10},{t:this.mh10},{t:this.fh11},{t:this.mh11},{t:this.fh12},{t:this.mh12},{t:this.fh13},{t:this.mh13},{t:this.fh14},{t:this.mh14},{t:this.fh15},{t:this.mh15},{t:this.fh16},{t:this.mh16},{t:this.fh17},{t:this.mh17},{t:this.fh18},{t:this.mh18},{t:this.instance_2},{t:this.m1},{t:this.f1},{t:this.b1},{t:this.m2},{t:this.f2},{t:this.b2},{t:this.m3},{t:this.f3},{t:this.b3},{t:this.m4},{t:this.f4},{t:this.b4},{t:this.m5},{t:this.f5},{t:this.b5},{t:this.m6},{t:this.f6},{t:this.b6},{t:this.m7},{t:this.f7},{t:this.b7},{t:this.m8},{t:this.f8},{t:this.b8},{t:this.m9},{t:this.f9},{t:this.b9},{t:this.m10},{t:this.f10},{t:this.b10},{t:this.m11},{t:this.f11},{t:this.b11},{t:this.m12},{t:this.f12},{t:this.b12},{t:this.m13},{t:this.f13},{t:this.b13},{t:this.m14},{t:this.f14},{t:this.b14},{t:this.m15},{t:this.f15},{t:this.b15},{t:this.m16},{t:this.f16},{t:this.b16},{t:this.m17},{t:this.f17},{t:this.b17},{t:this.m18},{t:this.f18},{t:this.b18},{t:this.bb1},{t:this.bb2},{t:this.bb3},{t:this.bb4},{t:this.bb6},{t:this.bb5},{t:this.bb7},{t:this.bb8},{t:this.bb9},{t:this.bb10},{t:this.bb11},{t:this.bb12},{t:this.bb13},{t:this.bb14},{t:this.bb15},{t:this.bb16},{t:this.bb17},{t:this.bb18},{t:this.ff2},{t:this.ff3},{t:this.ff4},{t:this.ff5},{t:this.ff6},{t:this.ff7},{t:this.ff8},{t:this.ff9},{t:this.ff10},{t:this.ff11},{t:this.ff12},{t:this.ff13},{t:this.ff14},{t:this.ff15},{t:this.ff16},{t:this.ff17},{t:this.ff18},{t:this.ff1},{t:this.mm1},{t:this.mm2},{t:this.mm3},{t:this.mm4},{t:this.mm5},{t:this.mm6},{t:this.mm7},{t:this.mm8},{t:this.mm9},{t:this.mm10},{t:this.mm11},{t:this.mm12},{t:this.mm13},{t:this.mm14},{t:this.mm15},{t:this.mm16},{t:this.mm17},{t:this.mm18}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(639.8,391,640,391.79999999999995);
// library properties:
lib.properties = {
	id: '0B2B3EBA4B645D45A7E84D318570440E',
	width: 1280,
	height: 783,
	fps: 60,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/CachedBmp_1.png?1658223689870", id:"CachedBmp_1"},
		{src:"images/Puberty for girls and boys_atlas_1.png?1658223689781", id:"Puberty for girls and boys_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['0B2B3EBA4B645D45A7E84D318570440E'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;