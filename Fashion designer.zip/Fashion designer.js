(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Fashion designer_atlas_1", frames: [[1752,346,124,76],[1878,346,124,76],[1179,234,150,76],[1131,312,150,76],[0,0,1362,232],[1541,232,260,66],[191,302,186,66],[379,302,186,66],[1593,68,227,66],[655,234,260,66],[567,302,186,66],[755,302,186,66],[1541,300,209,66],[1803,278,212,66],[943,302,186,66],[917,234,260,66],[0,302,189,66],[1593,0,443,66],[1364,164,461,66],[330,234,323,66],[0,234,328,66],[1364,0,227,162],[1364,232,175,141],[1827,68,132,208]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_23 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_22 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_21 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_20 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_19 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_18 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_17 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_16 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_15 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_14 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_13 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_12 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_11 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_10 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_8 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_7 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_6 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_5 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_3 = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_2 = function() {
	this.initialize(img.CachedBmp_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2470,1262);


(lib.CachedBmp_1 = function() {
	this.initialize(img.CachedBmp_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2480,374);


(lib.Screenshot_20220531_104840removebgpreview = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Screenshot_20220531_104847removebgpreview = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Screenshot_20220531_104901removebgpreview = function() {
	this.initialize(ss["Fashion designer_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.startbutton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {up:0,over:1,down:2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.CachedBmp_22();
	this.instance.setTransform(-15.2,-13.8,0.3362,0.3362);

	this.instance_1 = new lib.CachedBmp_23();
	this.instance_1.setTransform(-18.9,-14.3,0.3362,0.3362);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(2));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAwDDIljAAQgtAAAAgtIAAkrQAAgtAtAAIFjAAIEEAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape.setTransform(2.775,-1.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF6600").s().p("AkpDDQgtAAAAgtIAAkrQAAgtAtAAIJTAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_1.setTransform(3.125,-1.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF6600").s().p("AkfDDQgtAAAAgtIAAkrQAAgtAtAAII/AAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_2.setTransform(0.775,-1.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.5,-21,70.6,39);


(lib.resetbutton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"up":0,"over":1,"down":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.CachedBmp_20();
	this.instance.setTransform(-22.45,-13.8,0.3362,0.3362);

	this.instance_1 = new lib.CachedBmp_21();
	this.instance_1.setTransform(-23.45,-13.8,0.3362,0.3362);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(2));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAwDDIljAAQgtAAAAgtIAAkrQAAgtAtAAIFjAAIEEAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape.setTransform(2.775,-1.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF6600").s().p("AkpDDQgtAAAAgtIAAkrQAAgtAtAAIJTAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_1.setTransform(1.775,-1.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF6600").s().p("AkfDDQgtAAAAgtIAAkrQAAgtAtAAII/AAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_2.setTransform(0.775,-1.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.5,-21,70.6,39);


(lib.helptext = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.instance = new lib.CachedBmp_19();
	this.instance.setTransform(-276.9,-30.5,0.3362,0.3362);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#393939").ss(2,1,1).p("EAjyAGQMhHjAAAIAAsfMBHjAAAg");
	this.shape.setTransform(-47.9,9.45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EgjxAGQIAAsfMBHjAAAIAAMfg");
	this.shape_1.setTransform(-47.9,9.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.helptext, new cjs.Rectangle(-277.9,-31.5,460,82), null);


(lib.border = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("Eg39AjNQhjAAAAhjMAAAhDTQAAhjBjAAMBv7AAAQBjAAAABjMAAABDTQAABjhjAAgEg39AbUMBotAAAIHOAAMAAAg7QInOAAMhotAAAg");
	this.shape.setTransform(4.05,2.575);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-364,-222.7,736.2,450.6);


(lib.handbags_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_18();
	this.instance.setTransform(659.2,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_17();
	this.instance_1.setTransform(347.35,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_16();
	this.instance_2.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.handbags_mc, new cjs.Rectangle(0,0,789.2,33), null);


(lib.handbags = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Screenshot_20220531_104847removebgpreview();
	this.instance.setTransform(104.7,0,0.6817,0.7461);

	this.instance_1 = new lib.CachedBmp_15();
	this.instance_1.setTransform(0,14.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,224,105.2);


(lib.footwear_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_14();
	this.instance.setTransform(659.2,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_13();
	this.instance_1.setTransform(347.35,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_12();
	this.instance_2.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.footwear_mc, new cjs.Rectangle(0,0,789.2,33), null);


(lib.footwear = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Screenshot_20220531_104840removebgpreview();
	this.instance.setTransform(86.35,0,0.6497,0.6806);

	this.instance_1 = new lib.CachedBmp_11();
	this.instance_1.setTransform(0,24.6,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,233.9,110.3);


(lib.clothing_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_10();
	this.instance.setTransform(659.2,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_9();
	this.instance_1.setTransform(347.35,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_8();
	this.instance_2.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.clothing_mc, new cjs.Rectangle(0,0,765.2,33), null);


(lib.clothing = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Screenshot_20220531_104901removebgpreview();
	this.instance.setTransform(121.7,0,0.85,0.962);

	this.instance_1 = new lib.CachedBmp_7();
	this.instance_1.setTransform(0,80.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,233.9,200.1);


(lib.helpbutton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"up":0,"over":1,"down":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.helptext();
	this.instance.setTransform(-13.2,-85.85,1,1,0,0,0,66.2,-6.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(2));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AgPBYQgEgFAAgGQAAgIAFgEQAEgEAIgBQAHABAFAEQAEAEAAAIQAAAGgEAFQgEAFgIAAQgIAAgFgFgAgRAmQAAgRAEgJQAEgLAMgLQAMgLADgFQAFgIAAgIQAAgMgGgGQgFgHgMABQgJgBgHAHQgHAGAAAJIgeAAQAAgVAPgOQAPgMAXAAQAZAAAPAMQAOAOAAAWQAAAUgUAVIgPAOQgIAJgBASg");
	this.shape.setTransform(0.625,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgPBYQgEgFAAgGQAAgIAFgEQAEgEAIgBQAHABAFAEQAEAEAAAIQAAAGgEAFQgEAFgIAAQgIAAgFgFgAgRAmQAAgRAEgJQAEgLAMgLQAMgLADgFQAFgIAAgIQAAgMgGgGQgFgHgMABQgJgBgHAHQgHAGAAAJIgeAAQAAgVAPgOQAPgMAXAAQAZAAAPAMQAOAOAAAWQAAAUgUAVIgPAOQgIAJgBASg");
	this.shape_1.setTransform(0.625,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(2));

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ai2DDQgsAAAAguIAAkqQAAgtAsAAIFtAAQAsAAAAAtIAAEqQAAAugsAAg");
	this.shape_2.setTransform(0,-0.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF6600").s().p("Ai2DDQgsAAAAguIAAkqQAAgtAsAAIFtAAQAsAAAAAtIAAEqQAAAugsAAg");
	this.shape_3.setTransform(0,-0.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2}]}).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-357.3,-111.2,460,129.9);


// stage content:
(lib.Fashiondesigner = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		
		
		this.start_mc.addEventListener("click", fl_ClickToGoToAndStopAtFrame_10.bind(this));
		function fl_ClickToGoToAndStopAtFrame_10()
		{
			this.gotoAndStop(1);
		}
		
		
		this.reset_mc.addEventListener("click", fl_ClickToGoToAndStopAtFrame_11.bind(this));
		function fl_ClickToGoToAndStopAtFrame_11()
		{
			this.gotoAndStop(0);
		}
		
		this.footwear_mc.visible = false;
		function fl_MouseClickHandler()
		{
		    this.footwear_mc.visible = !this.footwear_mc.visible;
		}
		this.footwear_mc.visible = false;
		this.footwearbtn.addEventListener("click", fl_MouseClickHandler.bind(this));
		
		
		this.handbags_mc.visible = false;
		function f2_MouseClickHandler()
		{
		    this.handbags_mc.visible = !this.handbags_mc.visible;
		}
		this.handbags_mc.visible = false;
		this.handbagsbtn.addEventListener("click", f2_MouseClickHandler.bind(this));
		
		
		this.clothing_mc.visible = false;
		function f3_MouseClickHandler()
		{
		    this.clothing_mc.visible = !this.clothing_mc.visible;
		}
		this.clothing_mc.visible = false;
		this.clothingbtn.addEventListener("click", f3_MouseClickHandler.bind(this));
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// interface_buttons
	this.start_mc = new lib.startbutton();
	this.start_mc.name = "start_mc";
	this.start_mc.setTransform(627.85,514.65,1.487,1.487);
	new cjs.ButtonHelper(this.start_mc, 0, 1, 2);

	this.help_mc = new lib.helpbutton();
	this.help_mc.name = "help_mc";
	this.help_mc.setTransform(1107.15,737.3,1.487,1.487,0,0,0,0,0.1);
	new cjs.ButtonHelper(this.help_mc, 0, 1, 2);

	this.reset_mc = new lib.resetbutton();
	this.reset_mc.name = "reset_mc";
	this.reset_mc.setTransform(1201.35,738.3,1.487,1.487);
	new cjs.ButtonHelper(this.reset_mc, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.reset_mc},{t:this.help_mc},{t:this.start_mc}]}).to({state:[{t:this.reset_mc},{t:this.help_mc}]},1).wait(1));

	// border
	this.instance = new lib.border("synched",0);
	this.instance.setTransform(632.7,386.65,1.7386,1.7386);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({startPosition:0},0).wait(1));

	// Text
	this.instance_1 = new lib.CachedBmp_1();
	this.instance_1.setTransform(17.95,238.3,0.5,0.5);

	this.clothing_mc = new lib.clothing_mc();
	this.clothing_mc.name = "clothing_mc";
	this.clothing_mc.setTransform(768.55,589.8,1,1,0,0,0,382.7,16.4);

	this.handbags_mc = new lib.handbags_mc();
	this.handbags_mc.name = "handbags_mc";
	this.handbags_mc.setTransform(780.35,403,1,1,0,0,0,394.5,16.4);

	this.footwear_mc = new lib.footwear_mc();
	this.footwear_mc.name = "footwear_mc";
	this.footwear_mc.setTransform(780.35,220.15,1,1,0,0,0,394.5,16.4);

	this.clothingbtn = new lib.clothing();
	this.clothingbtn.name = "clothingbtn";
	this.clothingbtn.setTransform(151.45,590.85,1,1,0,0,0,117,100);
	new cjs.ButtonHelper(this.clothingbtn, 0, 1, 1);

	this.handbagsbtn = new lib.handbags();
	this.handbagsbtn.name = "handbagsbtn";
	this.handbagsbtn.setTransform(146.45,416.45,1,1,0,0,0,112,52.6);
	new cjs.ButtonHelper(this.handbagsbtn, 0, 1, 1);

	this.footwearbtn = new lib.footwear();
	this.footwearbtn.name = "footwearbtn";
	this.footwearbtn.setTransform(151.35,228.35,1,1,0,0,0,116.9,55.1);
	new cjs.ButtonHelper(this.footwearbtn, 0, 1, 1);

	this.instance_2 = new lib.CachedBmp_6();
	this.instance_2.setTransform(1011.1,82.55,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_5();
	this.instance_3.setTransform(648.85,82.55,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_4();
	this.instance_4.setTransform(343.75,82.55,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_3();
	this.instance_5.setTransform(34.45,82.55,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_2();
	this.instance_6.setTransform(22.35,58.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.footwearbtn},{t:this.handbagsbtn},{t:this.clothingbtn},{t:this.footwear_mc},{t:this.handbags_mc},{t:this.clothing_mc}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(639.8,391,640,391.79999999999995);
// library properties:
lib.properties = {
	id: '0B2B3EBA4B645D45A7E84D318570440E',
	width: 1280,
	height: 783,
	fps: 60,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/CachedBmp_2.png?1653990494111", id:"CachedBmp_2"},
		{src:"images/CachedBmp_1.png?1653990494111", id:"CachedBmp_1"},
		{src:"images/Fashion designer_atlas_1.png?1653990494076", id:"Fashion designer_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['0B2B3EBA4B645D45A7E84D318570440E'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;