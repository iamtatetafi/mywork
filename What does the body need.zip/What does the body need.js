(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"What does the body need_atlas_1", frames: [[1040,846,39,80],[0,1519,633,250],[1138,846,641,258],[1040,928,39,80],[888,0,677,312],[451,1047,685,310],[0,0,449,1135],[296,1137,124,76],[0,1215,124,76],[0,1137,146,76],[148,1137,146,76],[888,846,150,76],[888,924,150,76],[0,1359,1249,158],[1081,846,39,80],[1251,1358,649,250],[888,578,649,266],[1081,928,39,80],[1230,1610,578,189],[635,1519,593,206],[126,1215,39,80],[1138,1106,654,250],[888,314,665,262],[167,1215,39,80],[451,0,435,1045],[623,1771,578,127],[0,1771,621,146],[1555,314,287,365]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_72 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_71 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_70 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_69 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_68 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_67 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_66 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_65 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_64 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_63 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_62 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_61 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_60 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_59 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_58 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_57 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_56 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_55 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_54 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_53 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_52 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_51 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_50 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_49 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_48 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_47 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_46 = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_45 = function() {
	this.initialize(img.CachedBmp_45);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2494,312);


(lib.Screenshot_20220516_105621removebgpreview = function() {
	this.initialize(ss["What does the body need_atlas_1"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.organsx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_72();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,19.5,40);


(lib.organsbtn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ACvFeIgKAAIgPAAIgOAAIgPAAIgOAAIgXAAIgVgBIgZgCIgMgCIgNgFIgNgFIgIgGIgIgGIgGgIIgIgKIgIgKIgHgMIgMgUIgKgUIgKgYIgFgLIgCgMIgDgPIABgPIABgOIAEgPIABgDIgLAIIgKAHIgMAGIgMAFIgLADIgIAHIgIAFIgJAFIgKADIgKADIgJAGIgKAGIgLADIgLACIgMADIgLACIgNAAIgZABIgNAAIgDABIgNAHIgOAGIgJAEIgKAGIgMAFIgMAFIgNABIgMACIgMABIgLAAIgLgCIgMgDIgLgEIgKgFIgJgHIgIgIIgHgIIgGgJIgIgVQgEgLgCgMQgDgSAAgUQgBgXAEgWQADgMAEgNQAGgTAJgRIAEgIIAEgFIAFgIIAHgHIAGgGIAEgIIAGgIIAGgIIAHgHIAGgGIAGgEIAFgNIAHgMIAIgKIALgJIALgHIANgFIgBgLIABgMIACgLIAEgKIAGgKIAHgJIAHgIIAJgHIAKgGIAIgGIAIgGIAKgFIAKgEQAAAAABAAQABAAAAAAQABgBAAAAQAAgBABAAQADgDABgEIAEgIIAGgIIAGgIIAIgGIAJgGIAKgGIALgEIALgFIAPgCIAPgCIAPgBIAOAAIAIAAIAIAAIALgGIAMgEIALgFIAKgBIALgCIAKgBIAFgEIANgFIACgBIAMgFIAMgDIANgCIANgBIAJAAIAEgCIAHgEIANgFIALgDIAXgEIAbgCIAogBIAYAAIAYACIAWAGIAKACIAJAFIAJAGIAGAGIACABIAIAGIAIAFIAAAAIAIAHIAHAIIAJAGIAMADIANADIAJAEIAKAEIAIAHIAIAGIABABIAKAGIAJAFIAKAGIALAGIAKAGIAKAJIAIAKIAIALIAHALIAGAHIAFAIIAFAJIAEAJIADAJIACANIABAMIAAAAIABALIAFAFIAJAIIAHAJIAFALIAGAMIAEAPIACANIACAPIAGAQIAHATIABAFQAGASAAATIABApIAAAqQAAAbgIAaIgEALIgGALIgHAKIgIAKIgJAIIgHAHIgJAGIgJAFIgKADIgFACIgEAEIgKAKIgKAIIgLAIIgIAFIgJADIgKADIgKADIgMACIgNABIgLAGIgMAGIgMAFIgMADIgKAFIgJAEIgKAEIgNADIgaAEIgPABIgOABIgLAAgAE9CKIgCADIgDAGQAAABAAAAQAAABAAAAQAAgBABAAQAAgBABgCIAFgFIACgDIgBAAIgDABgAFdB0IgCACIgDACIgCACIADgCIACgBIACgBIAAgCgAmoBbIACAAIACgBIgCAAIgCABgAmjBaIABAAIABAAIgCAAg");
	this.shape.setTransform(50.9222,34.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,101.9,69.9);


(lib.organs_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_71();
	this.instance.setTransform(6.35,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_70();
	this.instance_1.setTransform(-1.5,1.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.organs_mc, new cjs.Rectangle(-1.5,0,324.4,130.3), null);


(lib.musclesx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_69();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,19.5,40);


(lib.muscles_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_68();
	this.instance.setTransform(4.95,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_67();
	this.instance_1.setTransform(-1.5,3.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.muscles_mc, new cjs.Rectangle(-1.5,0,345,158.3), null);


(lib.musclebtn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_66();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,224.5,567.5);


(lib.startbutton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {up:0,over:1,down:2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.CachedBmp_64();
	this.instance.setTransform(-15.2,-13.8,0.3362,0.3362);

	this.instance_1 = new lib.CachedBmp_65();
	this.instance_1.setTransform(-18.9,-14.3,0.3362,0.3362);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(2));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAwDDIljAAQgtAAAAgtIAAkrQAAgtAtAAIFjAAIEEAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape.setTransform(2.775,-1.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF6600").s().p("AkpDDQgtAAAAgtIAAkrQAAgtAtAAIJTAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_1.setTransform(3.125,-1.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF6600").s().p("AkfDDQgtAAAAgtIAAkrQAAgtAtAAII/AAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_2.setTransform(0.775,-1.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.5,-21,70.6,39);


(lib.solvebutton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"up":0,"over":1,"down":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.CachedBmp_62();
	this.instance.setTransform(-21.7,-13.8,0.3362,0.3362);

	this.instance_1 = new lib.CachedBmp_63();
	this.instance_1.setTransform(-22.7,-13.8,0.3362,0.3362);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(2));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAwDDIljAAQgtAAAAgtIAAkrQAAgtAtAAIFjAAIEEAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape.setTransform(2.775,-1.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF6600").s().p("AkpDDQgtAAAAgtIAAkrQAAgtAtAAIJTAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_1.setTransform(1.775,-1.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF6600").s().p("AkfDDQgtAAAAgtIAAkrQAAgtAtAAII/AAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_2.setTransform(0.775,-1.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.5,-21,70.6,39);


(lib.resetbutton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"up":0,"over":1,"down":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.CachedBmp_60();
	this.instance.setTransform(-22.45,-13.8,0.3362,0.3362);

	this.instance_1 = new lib.CachedBmp_61();
	this.instance_1.setTransform(-23.45,-13.8,0.3362,0.3362);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(2));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAwDDIljAAQgtAAAAgtIAAkrQAAgtAtAAIFjAAIEEAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape.setTransform(2.775,-1.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF6600").s().p("AkpDDQgtAAAAgtIAAkrQAAgtAtAAIJTAAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_1.setTransform(1.775,-1.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF6600").s().p("AkfDDQgtAAAAgtIAAkrQAAgtAtAAII/AAQAtAAAAAtIAAErQAAAtgtAAg");
	this.shape_2.setTransform(0.775,-1.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.5,-21,70.6,39);


(lib.helptext = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.instance = new lib.CachedBmp_59();
	this.instance.setTransform(-146.9,-21.05,0.3362,0.3362);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#393939").ss(2,1,1).p("EAhmAE4MhDLAAAIAApvMBDLAAAg");
	this.shape.setTransform(60.1,4.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EghlAE4IAApvMBDLAAAIAAJvg");
	this.shape_1.setTransform(60.1,4.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.helptext, new cjs.Rectangle(-155.9,-27.6,432,64.5), null);


(lib.border = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("Eg39AjNQhjAAAAhjMAAAhDTQAAhjBjAAMBv7AAAQBjAAAABjMAAABDTQAABjhjAAgEg39AbUMBotAAAIHOAAMAAAg7QInOAAMhotAAAg");
	this.shape.setTransform(4.05,2.575);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-364,-222.7,736.2,450.6);


(lib.heartx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_58();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,19.5,40);


(lib.heartbtn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAZDcIgCAAIgJgBIgLgCIgKgDIgLgDIgKgFIgKgGIgIgIIgJgKIgHgLIgFgLIgNgBIgMgDIgLgEIgLgFIgLgGIgJgIIgJgIIgGgGIgFgGIgJgEIgLgGIgJgIIgJgHIgIgHIgIgHIgHgHIgFgIIgGgNIgGgOIgDgOIgCgbIgBgbIgBgbIABgaIAAgCIABgVIACgJIADgKIADgJIAFgJIAGgJIAHgIIAIgHIAEgDIAGgDIAJgFIAKgFIAKgIIAKgFIALgFIAMgFIAOgDIAPgCIAOgBIAOgBIAJABIAJAAIANACIAMADIAMADIALAGIAIAFIATAAIAcAAIAbAAIALABIAMACIAEABIAHACIAKADIALAFIAJAGIAJAIIAIAKIAHALIABACIAFAJIAJAIIAKAIIAJAIIAHAIIAGAIIAHAIIAHAMIAFAMIAFANIADAMQADATAAATIABAlIAAAfIAAAsIgBALIgBAOIgCAJIgCAGIgBAEIgDAJIgFAJIgGAJIgHAIIgJAIIgLAIIgMAFIgMAFIgcAEIgdACIgDAAIgaABIgZAAIgQAAIgQAAg");
	this.shape.setTransform(23.9875,21.9875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,48,44);


(lib.heart_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_57();
	this.instance.setTransform(2.95,1.2,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_56();
	this.instance_1.setTransform(-1.5,-1.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.heart_mc, new cjs.Rectangle(-1.5,-1.5,329,133), null);


(lib.brainx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_55();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,19.5,40);


(lib.brainbtn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhiC/IgOAAIgeAAIggAAIgfAAIgfAAIgfAAIgagBIgKgCIgKgEIgJgEIgJgGIgIgHIgHgIIgGgIIgEgJIgDgKIgDgLIgBgKIABgLIADgLIADgKIAFgJIAGgJIAIgIIAIgHIgEgBIgKgDIgJgEIgJgGIgHgHIgHgIIgGgIIgEgJIgEgJIgDgOIAAgOIADgNIAFgNIAGgMIADgIIABgJIAFgMIAGgLIAHgLIAIgLIAFgIIAGgIIAIgHIAHgHIAJgGIAJgEIAKgEIALgDQAngGApABQA1ABA3AAICdAAQBKgBBKAFQAQABAPACIAOAFIAMAEIAOAFIANAEIANAEIALAEIAKAFIAJAGIAJAHIAIAJIAHAJIAFAMIAFAMIACAMIABANIABAMIAAANIABAMIAAABIAFALIAEALIAEAKIACAMIABAMIAAAMIgBANIgDAMIgEAMIgFALIgHAKIgJAKIgJAIIgKAGIgKAFIgXAFIgWACIgYABIgaAAIgdAAIgcAAIgdABIgGAEIgOAGIgNAFIgJABIgQADIgPABIgLAAIgLAAIAAABIgLAEIgLAFIgNAEIgKACIgKACIgJABIgGAFIgKAEIgKAEIgKADIgPACIgNABIgPABIgNAAg");
	this.shape.setTransform(39.25,19.0429);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,78.5,38.1);


(lib.brain_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_54();
	this.instance.setTransform(4.95,1.2,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_53();
	this.instance_1.setTransform(-1.5,-1.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.brain_mc, new cjs.Rectangle(-1.5,-1.5,296.5,103), null);


(lib.bowelx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_52();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,19.5,40);


(lib.bowelbtn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AA8HpIgMgBIgLgCIgLgFIgMgFIgLgGIgNgBIgNgCIgNgDIgMgEIgNgGIgKgGIgIgJIgIgJIgNAAIgNAAIgNAAIgNAAIgMAAIgNAAIgNgCIgYgFIgKgEIgJgEIgIgGIgNgCIgNgBIgMgEIgLgFIgLgIIgNgBIgMgCIgLgEIgLgEIgKgGIgKgFIgNgGIgNgGIgIgFIgIgHIgHgHIgKgIIgJgJIgIgLIgGgNIgFgOIgFgGIgEgGIgGgJIgFgJIgFgJIgHgMIgFgMIgEgNIgBgGIgIgMIgFgMIgGgNIgDgMIgBgOIgBgMIgBgLIgGgLIgFgMIgDgLIgEgXIgCgYIAAgYIAAgZIAAgaIABgZIADgZIAFgNIAGgOIAEgGIABgPIABgNIACgOIAEgMIAEgKIAEgKIAFgIIAHgIIAHgHIAJgGIgCgLIgBgMIABgMIADgLIAFgLIAGgKIAIgJIAJgIIAJgIIAKgHIAKgFIAKgGIACgBIAGgJIAGgIIAHgGIAIgFIAIgFIANgFQAogMAqAAIBYACIBaAAIBnAAIA9AAIAKgIIAKgIIAKgHIALgGIAMgEIALgCIAAAAIABAAIACgDIACgBIAEgFIAHgHIAHgHIAIgJIAJgJIAKgHIANgFIANgGIANgCIANgCIANgBIAOgBIAPABIAOABIAPACIANAFIAOAFIAKAIIAMAEIALAFIALAGIAKAHIAKAJIAJAIIAJAJIAIALIAFALIAKAFIAJAIIAJAHIAKAJIAJAJIAIALIAEAJIAEAJIADAKIAHAIIAFAKIAFAJIAEALQAJA4gBA6QgCA9AAA9IAAB4IAAB4QAAAcgJAaIgFAKIgGAJIgHAJIgJAHIgKAHIgLAGIgLAEIgNAEIgNACIgIAEIgIAFIgJAGIgKADIgKABIgKABIgLABIgKABQgDAAgCACQgEABgCAEIgGAHIgKAIIgLAIIgLAEIgMAGIgKAEIgJAFIgKAEIgJADIgJADIgKAHIgLAEIgLAFIgLACIgBAEIgDALIgEAKIgFALIgGAJIgHAIIgIAHIgJAFIgKAFIgKAEIgKADIgKACIgNACIgMABIgMAAIgNAAIgOABg");
	this.shape.setTransform(53.0107,48.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,106,97.8);


(lib.bowel_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_51();
	this.instance.setTransform(6.35,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_50();
	this.instance_1.setTransform(-1.5,-0.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bowel_mc, new cjs.Rectangle(-1.5,-0.7,334.9,131), null);


(lib.bonesx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_49();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,19.5,40);


(lib.bonesbtn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_48();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,217.5,522.5);


(lib.bones_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_47();
	this.instance.setTransform(4.35,1.15,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_46();
	this.instance_1.setTransform(-1.5,-1.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bones_mc, new cjs.Rectangle(-1.5,-1.5,310.5,73), null);


(lib.helpbutton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"up":0,"over":1,"down":2};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.helptext();
	this.instance.setTransform(-27.9,-73.7,1,1,0,0,0,66.2,-6.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(2));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AgPBYQgEgFAAgGQAAgIAFgEQAEgEAIgBQAHABAFAEQAEAEAAAIQAAAGgEAFQgEAFgIAAQgIAAgFgFgAgRAmQAAgRAEgJQAEgLAMgLQAMgLADgFQAFgIAAgIQAAgMgGgGQgFgHgMABQgJgBgHAHQgHAGAAAJIgeAAQAAgVAPgOQAPgMAXAAQAZAAAPAMQAOAOAAAWQAAAUgUAVIgPAOQgIAJgBASg");
	this.shape.setTransform(0.625,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgPBYQgEgFAAgGQAAgIAFgEQAEgEAIgBQAHABAFAEQAEAEAAAIQAAAGgEAFQgEAFgIAAQgIAAgFgFgAgRAmQAAgRAEgJQAEgLAMgLQAMgLADgFQAFgIAAgIQAAgMgGgGQgFgHgMABQgJgBgHAHQgHAGAAAJIgeAAQAAgVAPgOQAPgMAXAAQAZAAAPAMQAOAOAAAWQAAAUgUAVIgPAOQgIAJgBASg");
	this.shape_1.setTransform(0.625,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(2));

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ai2DDQgsAAAAguIAAkqQAAgtAsAAIFtAAQAsAAAAAtIAAEqQAAAugsAAg");
	this.shape_2.setTransform(0,-0.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF6600").s().p("Ai2DDQgsAAAAguIAAkqQAAgtAsAAIFtAAQAsAAAAAtIAAEqQAAAugsAAg");
	this.shape_3.setTransform(0,-0.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2}]}).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-250,-95.1,432,113.8);


// stage content:
(lib.Whatdoesthebodyneed = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		/* Click to Go to Frame and Stop
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and stops the movie.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		this.start_mc.addEventListener("click", fl_ClickToGoToAndStopAtFrame_10.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_10()
		{
			this.gotoAndStop(1);
		
		}
		
		/* Click to Go to Frame and Stop
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and stops the movie.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		this.reset_mc.addEventListener("click", fl_ClickToGoToAndStopAtFrame_11.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_11()
		{
			this.gotoAndStop(0);
		}
		
		/* Click to Go to Frame and Stop
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and stops the movie.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		this.solve_mc.addEventListener("click", fl_ClickToGoToAndStopAtFrame_13.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_13()
		{
		this.bones_mc.visible = true;
		this.bonesx.visible = true;
		this.bowel_mc.visible = true;
		this.bowelx.visible = true;
		this.brain_mc.visible = true;
		this.brainx.visible = true;
		this.heart_mc.visible = true;
		this.heartx.visible =  true;
		this.muscles_mc.visible = true;
		this.musclesx.visible = true;
		this.organs_mc.visible = true;
		this.organsx.visible = true;
		}
		
		this.bones_mc.visible = false;
		this.bonesx.visible = false;
		this.bowel_mc.visible = false;
		this.bowelx.visible = false;
		this.brain_mc.visible = false;
		this.brainx.visible = false;
		this.heart_mc.visible = false;
		this.heartx.visible =  false;
		this.muscles_mc.visible = false;
		this.musclesx.visible = false;
		this.organs_mc.visible = false;
		this.organsx.visible = false;
		
		
		/* Click to Hide an Object
		Clicking on the specified symbol instance hides it.
		
		Instructions:
		1. Use this code for objects that are currently visible.
		*/
		this.brainx.addEventListener("click", fl_ClickToHide_3.bind(this));
		
		function fl_ClickToHide_3()
		{
			this.brainx.visible = false;
			this.brain_mc.visible = false;
		}
		
		/* Click to Hide an Object
		Clicking on the specified symbol instance hides it.
		
		Instructions:
		1. Use this code for objects that are currently visible.
		*/
		this.musclesx.addEventListener("click", fl_ClickToHide_4.bind(this));
		
		function fl_ClickToHide_4()
		{
			this.musclesx.visible = false;
			this.muscles_mc.visible = false;
		}
		
		/* Click to Hide an Object
		Clicking on the specified symbol instance hides it.
		
		Instructions:
		1. Use this code for objects that are currently visible.
		*/
		this.heartx.addEventListener("click", fl_ClickToHide_5.bind(this));
		
		function fl_ClickToHide_5()
		{
			this.heartx.visible = false;
			this.heart_mc.visible = false;
		}
		
		/* Click to Hide an Object
		Clicking on the specified symbol instance hides it.
		
		Instructions:
		1. Use this code for objects that are currently visible.
		*/
		this.organsx.addEventListener("click", fl_ClickToHide_6.bind(this));
		
		function fl_ClickToHide_6()
		{
			this.organsx.visible = false;
			this.organs_mc.visible = false;
		}
		
		/* Click to Hide an Object
		Clicking on the specified symbol instance hides it.
		
		Instructions:
		1. Use this code for objects that are currently visible.
		*/
		this.bonesx.addEventListener("click", fl_ClickToHide_7.bind(this));
		
		function fl_ClickToHide_7()
		{
			this.bonesx.visible = false;
			this.bones_mc.visible = false;
		}
		
		/* Click to Hide an Object
		Clicking on the specified symbol instance hides it.
		
		Instructions:
		1. Use this code for objects that are currently visible.
		*/
		this.bowelx.addEventListener("click", fl_ClickToHide_8.bind(this));
		
		function fl_ClickToHide_8()
		{
			this.bowelx.visible = false;
			this.bowel_mc.visible = false;
		}
		
		
		/* Mouse Click Event
		Clicking on the specified symbol instance executes a function in which you can add your own custom code.
		
		Instructions:
		1. Add your custom code on a new line after the line that says "// Start your custom code" below.
		The code will execute when the symbol instance is clicked.
		*/
		
		this.musclebtn.addEventListener("click", fl_MouseClickHandler_4.bind(this));
		
		function fl_MouseClickHandler_4()
		{
			this.muscles_mc.visible = true;
			this.musclesx.visible = true;
		}
		
		/* Mouse Click Event
		Clicking on the specified symbol instance executes a function in which you can add your own custom code.
		
		Instructions:
		1. Add your custom code on a new line after the line that says "// Start your custom code" below.
		The code will execute when the symbol instance is clicked.
		*/
		
		this.brainbtn.addEventListener("click", fl_MouseClickHandler_5.bind(this));
		
		function fl_MouseClickHandler_5()
		{
			this.brain_mc.visible = true;
		    this.brainx.visible = true;
		}
		
		/* Mouse Click Event
		Clicking on the specified symbol instance executes a function in which you can add your own custom code.
		
		Instructions:
		1. Add your custom code on a new line after the line that says "// Start your custom code" below.
		The code will execute when the symbol instance is clicked.
		*/
		
		this.heartbtn.addEventListener("click", fl_MouseClickHandler_6.bind(this));
		
		function fl_MouseClickHandler_6()
		{
			this.heart_mc.visible = true;
		    this.heartx.visible =  true;
		}
		
		/* Mouse Click Event
		Clicking on the specified symbol instance executes a function in which you can add your own custom code.
		
		Instructions:
		1. Add your custom code on a new line after the line that says "// Start your custom code" below.
		The code will execute when the symbol instance is clicked.
		*/
		
		this.bonesbtn.addEventListener("click", fl_MouseClickHandler_7.bind(this));
		
		function fl_MouseClickHandler_7()
		{
			this.bones_mc.visible = true;
		    this.bonesx.visible = true;
		}
		
		/* Mouse Click Event
		Clicking on the specified symbol instance executes a function in which you can add your own custom code.
		
		Instructions:
		1. Add your custom code on a new line after the line that says "// Start your custom code" below.
		The code will execute when the symbol instance is clicked.
		*/
		
		this.bowelbtn.addEventListener("click", fl_MouseClickHandler_8.bind(this));
		
		function fl_MouseClickHandler_8()
		{
			this.bowel_mc.visible = true;
		    this.bowelx.visible = true;
		}
		
		/* Mouse Click Event
		Clicking on the specified symbol instance executes a function in which you can add your own custom code.
		
		Instructions:
		1. Add your custom code on a new line after the line that says "// Start your custom code" below.
		The code will execute when the symbol instance is clicked.
		*/
		
		this.organsbtn.addEventListener("click", fl_MouseClickHandler_9.bind(this));
		
		function fl_MouseClickHandler_9()
		{
			this.organs_mc.visible = true;
		    this.organsx.visible = true;
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Actions
	this.bowelbtn = new lib.bowelbtn();
	this.bowelbtn.name = "bowelbtn";
	this.bowelbtn.setTransform(650.05,308.55,1,1,0,0,0,53,48.9);
	this.bowelbtn.compositeOperation = "darken";
	new cjs.ButtonHelper(this.bowelbtn, 0, 1, 1);

	this.organsbtn = new lib.organsbtn();
	this.organsbtn.name = "organsbtn";
	this.organsbtn.setTransform(649.95,240.7,1,1,0,0,0,50.9,35);
	this.organsbtn.compositeOperation = "darken";
	new cjs.ButtonHelper(this.organsbtn, 0, 1, 1);

	this.bonesbtn = new lib.bonesbtn();
	this.bonesbtn.name = "bonesbtn";
	this.bonesbtn.setTransform(761.75,376.95,1,1,0,0,0,108.8,261.1);
	this.bonesbtn.compositeOperation = "darken";
	new cjs.ButtonHelper(this.bonesbtn, 0, 1, 1);

	this.heartbtn = new lib.heartbtn();
	this.heartbtn.name = "heartbtn";
	this.heartbtn.setTransform(654.9,187.65,1,1,0,0,0,23.9,21.9);
	this.heartbtn.compositeOperation = "darken";
	new cjs.ButtonHelper(this.heartbtn, 0, 1, 1);

	this.brainbtn = new lib.brainbtn();
	this.brainbtn.name = "brainbtn";
	this.brainbtn.setTransform(651.35,54.9,1,1,0,0,0,39.2,19.1);
	this.brainbtn.compositeOperation = "darken";
	new cjs.ButtonHelper(this.brainbtn, 0, 1, 1);

	this.musclebtn = new lib.musclebtn();
	this.musclebtn.name = "musclebtn";
	this.musclebtn.setTransform(538.7,400.2,1,1,0,0,0,112.1,283.8);
	this.musclebtn.compositeOperation = "darken";
	new cjs.ButtonHelper(this.musclebtn, 0, 1, 1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.047)").s().p("AgaBIIgGgGIgGgFIgFgGIgFgIIgEgHIgDgIIgCgHIgCgJIAAgIIAAgIIACgIIACgIIADgIIAEgIIAFgHIAFgFIAGgHIAGgEIAHgFIAHgEIAIgEIAHgCIAIgBIAJAAIAIAAIAJABIAIACIAHAEIAIAEIAAAAIgDACIgHAGIgKAAIgLABIgKACIgKAEIgJAEIgIAHIgIAGIgGAIIgGAIIgFAJIgDAKIgCAKIgBALIABAKIACAKIADAKIAFAJIADAGIgBgBg");
	this.shape.setTransform(517.2125,214.95);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0)").s().p("A1ARGIgKgCIgKgDIgJgFIgJgGIgIgGIgHgIIgFgJIgFgJIgDgKIgCgKIgCgLIACgMIADgMIAEgLIAGgKIAIgKIABgJIAEgMIAFgLIAIgKIAAgIIAAgMIAAgNIABgMIABgNIACgLIAEgLIAFgLIAGgKIAIgIIAIgHIAHgHIAIgGIAKgEIAJgDIALgJIANgGIAOgEIAKgIIAKgFIAMgEIAPgFIAOgFIAGgDIAHgEIAHgGIAHgGIAJgLIAKgIIAIgJIAJgIIAKgHIALgFIAFgKIAHgJIAIgIIAKgHIAKgFIALgEIALgEIALgCIALgCIAIgKIAHgHIAHgHIAGgHIAHgHIAIgIIAHgHIAHgGIAIgFIAEgLIAFgLIADgFIgCAEIgGANIgCANIgCAOIgFAJIgFAJIgEAIIgCAHIgCALIgCAKIgKAEIgKAFIgKAFIgIAJIgIAJIgHAGIgHAGIgOAIIgUAEQgbAHgZAOQgWALgUAOQgcASgaAVQgZAUgXAXQgbAcgVAhIgGAKIgDAMIgCAMIAAAMIACAMIADALIAGALIAFAJIAHAIIAIAGIAJAGIAJAEIAJAEIAMADIAKACIAMABIAKgBIAKgCIAAAAIgCADIgFAIIgBAJIgCAKIgCALIgGAKIgEALIgGAJIgHAIIgIAHIgKAGIgKAEIgKAEIgKADIgLABIgLABIgKgBgAunHsIAAgBIABgNIACgNIABgNIADgIIAEgJIAEgKIAGgIIAHgIIAGgFIAGgGIABgMIABgNIABgNIADgMIAEgLIAGgLIAGgJIAHgJIAGgKIAFgJIAFgKIAHgKIAGgKIAIgKIALgJIALgIIAFgLIAGgLIAHgKIAFgKIAGgKIAIgJIAIgIIAKgHIAKgFIALgEIAGgOIAGgOIAJgNIAKgMIAIgGIAHgHIAJgGIAIgJIAJgIIAEgPIAEgZQADgNAEgKIAKgYIAKgUIAGgKIAHgJIAJgIIAJgGIAKgFIALgEIAKgEIAGgIIAGgIIAIgGIAIgGIAOgFIANgFIANgFIAHgGIAIgHIAJgHIAKgHIALgFIAKgFIAMgDIAKgCIAKgBIALABIAKACIAKADIAEACIgKAHIgKgFIgMgCIgMgBIgLAAIgLACIgKAEIgJAEIgJAGIgIAHIgHAIIgFAIIgCACIgGAIIgFAFIgFAFIgKALIgHALIgHALIgHANIgMAYIgMAYIgJAWIgMAGIgKAIIgKAIIgJAIIgIAJIgGAJIgFALIgEALIgIAKIgKAKIgIAKIgGALIgEAJIgDAHIgDAFIgFAGIgFAEIgKAKIgJALIgJALIgIALIgFANIgGAOIgBAKIgBAKIgKAGIgKAIIgJAJIgJAKIgHAKIgIALIgGAHIgGAIIgFAIIgKAFIgJAFIgIAHIgHAJIgHAJIgHAJIgHAKIgFAKIgFALIgBAGIgKAHIgIAIIgHAJIgFAKIgGANIgFAOIgDAMIgGALIgJAIIgEAGIgFAGIgCACIAEgFgArDHeIAHgIIAHgJIAGgJIAIgDIAMgEIANgGIALgGIAJgHIAJgHIAJgIIAIgIIAIgIIAPgDIAOgEIAKgDIAJgEIgcATQgRALgQANIgVASQgPALgSAJIgVALIgMAFIgKADIADgDgAoeF4IADAAIgEAAIABAAgAS0BeIADgGIACgCQAAgBABAAQAAAAABAAQAAgBABAAQAAABAAAAIgCACIgEAGIgDADIABgCgATUBDIACgCIACgCIABAAIAAACIgCACIgCABIgDABIACgCgAVqg+IgGgQIgCgOIgDgOIgDgOIgGgNIgFgLIgIgJIgIgIIgFgEIgCgMIAIABIAKACIAKADIAJAFIAIAGIAIAGIAHAIIAGAJIAFALIAEAMIACANIAAANIgDAMIgEAKIgEAJIgGAIIgGAHIgGgUgAkUi4IgKgEIgJgEIgJgGIgIgHIgFgGIAEgBIAJgFIAIgFIAHgGIAHgIIAHgIIAAAIIAAAOIABAPIAAAMIACALIgEAAgARxlwIgJgGIgBgBIAHgDIALgIIAJgIIAHgIIAFgJIAGgJIADgJIABgEIAAAGIgBAMIgCANIgFALIgHALIgIAJIgJAIIgHgFgANAlzIgNgFIgOgEIgKgEIgKgEIgLgEIgKgFIgIgDIgGgFIgIgHIgJgGIgEgFIgLgDIgKgDIgKgDIgJgFIgIgGIgIgGIgHgHIgHgFIgHgGIgHgIIgGgJIgFgLIgDgLIgGgXQgCgNAAgNIgBgZIABgYIACgKIADgKIAFgJIAGgIIAGgIIAIgHIAJgGIAJgEIAKgEIAKgCIALgBIABAAIAAACIgBAaIABAbIABAbIACAcIADAOIAGAOIAGANIAEAIIAHAHIAJAHIAIAHIAJAHIAJAIIAKAGIAKAEIAFAGIAFAGIAJAIIAKAIIAKAGIAMAFIALAEIAMADIANABIAFALIAHALIAJAKIAGAGIgDACIgLABIgMABIgOABIgLADIgMAFIgGgBgAkInlIAGgLIAFgLIAFgNIAGgNIAFgNIACgNIACgNIACgNIAEgNIAGgOIAGgIIAGgHIAHgHIAHgJIABgKIACgKIADgKIAEgJIAEgKIAGgIIAHgIIAJgIIAKgHIAEgJIAGgJIAGgJIAJgLIAJgKIAJgLIAHgMIAIgNIAIgMIAGgJIAKgKIgCAFIgEALIgCALIgCALIgGAMIgFALIgEAMIgBANIgBAMIgBAMIAAANIAAAMIgBAMIgIAKIgIALIgIAMIgFAMIgGAMIgIAIIgHAJIgIAJIgGAJIgFAKIgDAKIgEAKIgKAIIgKAHIgJAIIgJAIIgTAVIgSAXIgFAFIgKAIIgGAEIAEgIgAiOrbIgCACIACgCIABgCIgBACgASdpKQgBgTgCgTIgEgMIgEgNIgFgMIgIgMIgGgIIgGgIIgIgIIgJgIIgJgIIgJgIIgFgJIAHAEIAJAFIAIAHIAHAGIAHAGIAHAHIAHAHIAGAJIAHANIAEANIAHAJIABACIAAA0IgBATIAAgPgALqr8IAIgJIAJgIIALgHIAKgEIALgEIALgCIABAAIAGgGIAJgGIAJgEIAKgEIAKgCIALAAIAbgBIAbAAIAaABQAMAAANABIAYAEIALAEIALAFIAKAIIAJAIIAIAKIACADIgEgBIgLgCIgLgBIgcAAIgbAAIgVAAIgHgFIgLgGIgMgDIgMgDIgNgCIgJAAIgJgBIgPABIgNABIgPACIgOADIgMAFIgLAFIgKAFIgKAIIgKAFIgJAFIgGADIAEgGgAArvWIAFgMIAEgJIAFgJIAHgKIAJgKIAEgIIAIgKIAIgLIAJgKIAHgHIAJgGIAKgEIAKgEIAKgCIAKAAIANABIAMADIALAEIALAHIACABIgPADIgJAEIgKAEIgJAFIgHAEIgIAGIgLAFIgKAFIgKAGIgJAIIgIAJIgIAKIgGAKIgFAFIgDACIgFACIgCABIgFADIgPAGIgJADIgDABIADgGgABKveIABAAIgCAAIABAAgABKveIAAAAg");
	this.shape_1.setTransform(560.8,245.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.musclebtn},{t:this.brainbtn},{t:this.heartbtn},{t:this.bonesbtn},{t:this.organsbtn},{t:this.bowelbtn}]},1).wait(1));

	// interface_buttons
	this.start_mc = new lib.startbutton();
	this.start_mc.name = "start_mc";
	this.start_mc.setTransform(627.85,514.65,1.487,1.487);
	new cjs.ButtonHelper(this.start_mc, 0, 1, 2);

	this.solve_mc = new lib.solvebutton();
	this.solve_mc.name = "solve_mc";
	this.solve_mc.setTransform(1082.35,738.3,1.487,1.487);
	new cjs.ButtonHelper(this.solve_mc, 0, 1, 2);

	this.help_mc = new lib.helpbutton();
	this.help_mc.name = "help_mc";
	this.help_mc.setTransform(987.15,737.3,1.487,1.487,0,0,0,0,0.1);
	new cjs.ButtonHelper(this.help_mc, 0, 1, 2);

	this.reset_mc = new lib.resetbutton();
	this.reset_mc.name = "reset_mc";
	this.reset_mc.setTransform(1201.35,738.3,1.487,1.487);
	new cjs.ButtonHelper(this.reset_mc, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.reset_mc},{t:this.help_mc},{t:this.solve_mc},{t:this.start_mc}]}).to({state:[{t:this.reset_mc},{t:this.help_mc},{t:this.solve_mc}]},1).wait(1));

	// border
	this.instance = new lib.border("synched",0);
	this.instance.setTransform(632.7,386.65,1.7386,1.7386);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({startPosition:0},0).wait(1));

	// Text
	this.instance_1 = new lib.CachedBmp_45();
	this.instance_1.setTransform(10.8,242.3,0.5,0.5);

	this.bowelx = new lib.bowelx();
	this.bowelx.name = "bowelx";
	this.bowelx.setTransform(1208.35,599,1,1,0,0,0,9.7,20);
	new cjs.ButtonHelper(this.bowelx, 0, 1, 1);

	this.bonesx = new lib.bonesx();
	this.bonesx.name = "bonesx";
	this.bonesx.setTransform(1191.8,375.4,1,1,0,0,0,9.7,20);
	new cjs.ButtonHelper(this.bonesx, 0, 1, 1);

	this.organsx = new lib.organsx();
	this.organsx.name = "organsx";
	this.organsx.setTransform(1200.35,211.65,1,1,0,0,0,9.7,20);
	new cjs.ButtonHelper(this.organsx, 0, 1, 1);

	this.heartx = new lib.heartx();
	this.heartx.name = "heartx";
	this.heartx.setTransform(347.75,599,1,1,0,0,0,9.7,20);
	new cjs.ButtonHelper(this.heartx, 0, 1, 1);

	this.musclesx = new lib.musclesx();
	this.musclesx.name = "musclesx";
	this.musclesx.setTransform(363.75,403.35,1,1,0,0,0,9.7,20);
	new cjs.ButtonHelper(this.musclesx, 0, 1, 1);

	this.brainx = new lib.brainx();
	this.brainx.name = "brainx";
	this.brainx.setTransform(319.7,181.7,1,1,0,0,0,9.7,20);
	new cjs.ButtonHelper(this.brainx, 0, 1, 1);

	this.bowel_mc = new lib.bowel_mc();
	this.bowel_mc.name = "bowel_mc";
	this.bowel_mc.setTransform(1066.6,555.1,1,1,0,0,0,166,64.7);

	this.bones_mc = new lib.bones_mc();
	this.bones_mc.name = "bones_mc";
	this.bones_mc.setTransform(1056.4,360.5,1,1,0,0,0,153.8,35);

	this.organs_mc = new lib.organs_mc();
	this.organs_mc.name = "organs_mc";
	this.organs_mc.setTransform(1061.3,168.05,1,1,0,0,0,160.7,65);

	this.heart_mc = new lib.heart_mc();
	this.heart_mc.name = "heart_mc";
	this.heart_mc.setTransform(208.95,554.1,1,1,0,0,0,163,64.9);

	this.brain_mc = new lib.brain_mc();
	this.brain_mc.name = "brain_mc";
	this.brain_mc.setTransform(190.75,151.75,1,1,0,0,0,146.8,49.9);

	this.muscles_mc = new lib.muscles_mc();
	this.muscles_mc.name = "muscles_mc";
	this.muscles_mc.setTransform(214.95,345.75,1,1,0,0,0,171,79);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0)").s().p("EApMAoaIAAz+MAzeAAAIAAT+gEhcVAoaIAA0SMAyPAAAIAAUSgEhcqAJ1IAA3tMA1DAAAIAAXtgEApgAFeIAAq6MAwDAAAIAAK6gEApMgUHIAAzqMAxnAAAIAATqgEhcqgYyIAAvnMAt3AAAIAAPng");
	this.shape_2.setTransform(637,360.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.shape_2},{t:this.muscles_mc},{t:this.brain_mc},{t:this.heart_mc},{t:this.organs_mc},{t:this.bones_mc},{t:this.bowel_mc},{t:this.brainx},{t:this.musclesx},{t:this.heartx},{t:this.organsx},{t:this.bonesx},{t:this.bowelx}]},1).wait(1));

	// picture
	this.instance_2 = new lib.Screenshot_20220516_105621removebgpreview();
	this.instance_2.setTransform(386.95,34.35,1.8118,1.8083);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).wait(1));

	// stageBackground
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("Ehljg+uMDLHAAAMAAAB9dMjLHAAAg");
	this.shape_3.setTransform(640,391.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("EhljA+vMAAAh9dMDLHAAAMAAAB9dg");
	this.shape_4.setTransform(640,391.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3}]}).wait(2));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(629,380.5,662,413.5);
// library properties:
lib.properties = {
	id: '0B2B3EBA4B645D45A7E84D318570440E',
	width: 1280,
	height: 783,
	fps: 60,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/CachedBmp_45.png?1653990898618", id:"CachedBmp_45"},
		{src:"images/What does the body need_atlas_1.png?1653990898577", id:"What does the body need_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['0B2B3EBA4B645D45A7E84D318570440E'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;